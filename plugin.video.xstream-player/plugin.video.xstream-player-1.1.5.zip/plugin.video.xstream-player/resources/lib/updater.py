"""Self-update system for XStream Player"""
import json
import os
import re
import sys
import time
import traceback
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from lang import _t

ADDON_ID = 'plugin.video.xstream-player'
# Security: HTTPS enforced URLs for update sources
RELEASES_API = 'https://api.github.com/repos/Pesicp/XStream-Player-Kodi21/contents/releases'
RELEASES_BASE = 'https://pesicp.github.io/XStream-Player-Kodi21/releases'


def get_addon():
    """Get addon instance"""
    return xbmcaddon.Addon(id=ADDON_ID)


def get_current_version():
    """Get currently installed version"""
    return get_addon().getAddonInfo('version')


def _version_key(v):
    """Parse a version string into a comparable tuple. Tolerates suffixes like '1.0.6-rc1'."""
    parts = re.findall(r'\d+', v or '')
    return tuple(int(p) for p in parts) if parts else (0,)


def _release_url(filename):
    url = f'{RELEASES_BASE}/{filename}'
    # Security: validate filename to prevent path traversal in URL construction
    import re
    if not re.match(r'^[\w\-.]+$', filename):
        raise ValueError(f'Invalid filename: {filename}')
    return url


# Short-lived in-process memo of fetch_all_versions(). Unauthenticated GitHub
# API is 60 req/h per IP — a user behind CGNAT or office NAT can easily burn
# the quota with repeated "Check for update" presses, which then surfaces a
# misleading "no versions" dialog. A 5 minute memo eliminates the burst.
_VERSIONS_CACHE_TTL = 300  # seconds
_versions_cache = {'ts': 0.0, 'data': None}


def fetch_all_versions(force=False):
    """Fetch all available versions from GitHub API.
    Returns list of dicts with 'version', 'filename', 'url' (sorted newest first).
    Results are memoised for _VERSIONS_CACHE_TTL seconds. Pass force=True to
    bypass the memo (e.g. for the revert-version UI which the user opens
    explicitly and expects fresh data for).
    """
    now = time.time()
    if not force and _versions_cache['data'] is not None and (now - _versions_cache['ts']) < _VERSIONS_CACHE_TTL:
        return _versions_cache['data']
    try:
        import urllib.request
        req = urllib.request.Request(RELEASES_API, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))

        versions = []
        for item in data:
            name = item.get('name', '')
            match = re.match(r'plugin\.video\.xstream-player-([\d.]+)\.zip', name)
            if match:
                versions.append({
                    'version': match.group(1),
                    'filename': name,
                    'url': _release_url(name),
                })

        versions.sort(key=lambda v: _version_key(v['version']), reverse=True)
        _versions_cache['ts'] = now
        _versions_cache['data'] = versions
        return versions
    except Exception as e:
        xbmc.log(f'[XStream Player] Failed to fetch versions: {str(e)}', xbmc.LOGERROR)
        # Don't poison the cache with a failure — keep serving the previous
        # successful result if we have one, otherwise return empty.
        return _versions_cache['data'] or []


def check_for_update():
    """Check if update is available.
    Returns: (update_available, latest_version, download_url)
    """
    versions = fetch_all_versions()
    if not versions:
        return False, None, None

    latest = versions[0]
    if _version_key(latest['version']) > _version_key(get_current_version()):
        return True, latest['version'], latest['url']
    return False, latest['version'], None


def _verify_zip(target_path):
    """Verify downloaded file is a valid ZIP and contains expected addon structure."""
    import zipfile
    try:
        with zipfile.ZipFile(target_path, 'r') as zf:
            # Check for corruption
            bad_file = zf.testzip()
            if bad_file:
                xbmc.log(f'[XStream Player] ZIP verification failed: {bad_file}', xbmc.LOGERROR)
                return False
            # Security: validate all entries are safe
            for name in zf.namelist():
                # Normalize path separators for cross-platform check
                normalized = name.replace('\\', '/')
                if normalized.startswith('..') or normalized.startswith('/'):
                    xbmc.log(f'[XStream Player] ZIP contains unsafe path: {name}', xbmc.LOGERROR)
                    return False
                # Block Windows-absolute paths (e.g., C:/foo, D:/bar)
                if len(normalized) >= 2 and normalized[1] == ':':
                    xbmc.log(f'[XStream Player] ZIP contains unsafe Windows path: {name}', xbmc.LOGERROR)
                    return False
                # Must be within expected addon directory
                if not normalized.startswith('plugin.video.xstream-player/'):
                    xbmc.log(f'[XStream Player] ZIP contains unexpected path: {name}', xbmc.LOGERROR)
                    return False
            # Must contain addon.xml
            if 'plugin.video.xstream-player/addon.xml' not in [n.replace('\\', '/') for n in zf.namelist()]:
                xbmc.log('[XStream Player] ZIP missing addon.xml', xbmc.LOGERROR)
                return False
        return True
    except zipfile.BadZipFile:
        xbmc.log('[XStream Player] Invalid ZIP file', xbmc.LOGERROR)
        return False
    except Exception as e:
        xbmc.log(f'[XStream Player] ZIP verification error: {str(e)}', xbmc.LOGERROR)
        return False


def download_update(url, target_path):
    """Download update zip to temp location with HTTPS enforcement and verification."""
    try:
        import urllib.request
        # Security: enforce HTTPS for downloads
        if not url.startswith('https://'):
            xbmc.log(f'[XStream Player] Update download rejected: non-HTTPS URL', xbmc.LOGERROR)
            return False
        
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=30) as response:
            # Limit download size (10MB max for addon)
            max_size = 10 * 1024 * 1024
            data = response.read(max_size + 1)
            if len(data) > max_size:
                xbmc.log('[XStream Player] Update download rejected: file too large', xbmc.LOGERROR)
                return False
            with open(target_path, 'wb') as f:
                f.write(data)
        
        # Verify the downloaded ZIP
        if not _verify_zip(target_path):
            os.remove(target_path)
            return False
        
        return True
    except Exception as e:
        xbmc.log(f'[XStream Player] Download failed: {str(e)}', xbmc.LOGERROR)
        xbmc.log(f'[XStream Player] Traceback: {traceback.format_exc()}', xbmc.LOGERROR)
        return False


def _perform_install(new_version, url, dialog, completion_title='Update Complete'):
    """Download, extract, and prompt-restart for a given version. Returns True on success."""
    import zipfile

    progress = xbmcgui.DialogProgress()
    progress.create('XStream Player', f'Downloading version {new_version}...')

    # Download to packages/ folder (Kodi standard location, like Fen Light)
    packages_dir = xbmcvfs.translatePath('special://home/addons/packages/')
    if not xbmcvfs.exists(packages_dir):
        xbmcvfs.mkdirs(packages_dir)
    zip_path = os.path.join(packages_dir, f'{ADDON_ID}-{new_version}.zip')

    success = download_update(url, zip_path)
    progress.close()

    if not success:
        dialog.notification('XStream Player', _t(30400), xbmcgui.NOTIFICATION_ERROR)
        return False

    progress = xbmcgui.DialogProgress()
    progress.create('XStream Player', _t(30401))

    addon_path = xbmcvfs.translatePath('special://home/addons/')
    try:
        # Security: validate addon_path is within expected location
        expected_base = os.path.normpath(xbmcvfs.translatePath('special://home/'))
        if not os.path.normpath(addon_path).startswith(expected_base):
            raise ValueError('Invalid addon installation path')
        
        # Security: verify ZIP structure before extraction
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            for member in zip_ref.namelist():
                target = os.path.normpath(os.path.join(addon_path, member))
                if not target.startswith(os.path.normpath(addon_path)):
                    raise ValueError(f'ZIP traversal attempt: {member}')

        # CRITICAL: Delete old addon folder first (like Fen Light)
        addon_folder = os.path.join(addon_path, ADDON_ID)
        if os.path.exists(addon_folder):
            import shutil
            shutil.rmtree(addon_folder)
            xbmc.log(f'[XStream Player] Removed old addon folder', xbmc.LOGINFO)

        # Extract fresh (silently)
        xbmc.log(f'[XStream Player] Extracting to: {addon_path}', xbmc.LOGINFO)
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(addon_path)

        # Give filesystem time to sync
        xbmc.sleep(1000)

        # Refresh addon database (disable/enable removed - was causing "remove from recents" popup)
        xbmc.executebuiltin('UpdateLocalAddons')
    except Exception as e:
        xbmc.log(f'[XStream Player] Extract failed: {str(e)}', xbmc.LOGERROR)
        progress.close()
        dialog.notification('XStream Player', _t(30710), xbmcgui.NOTIFICATION_ERROR)
        return False

    progress.close()

    # Update version setting so user sees new version in settings
    get_addon().setSetting('current_version_display', new_version)

    restart = dialog.yesno(
        completion_title,
        _t(30402, new_version),
        nolabel=_t(30403),
        yeslabel=_t(30404)
    )

    if restart:
        if xbmc.getCondVisibility('System.Platform.Android'):
            # RestartApp is a no-op on Android. Ask the user to fully close and reopen Kodi.
            xbmcgui.Dialog().ok(
                'XStream Player',
                'Update installed. Please fully close Kodi (swipe it away from recent apps) and reopen it to finish the update.'
            )
        else:
            xbmc.executebuiltin('RestartApp')
    return True


def do_direct_update_install(new_version, url):
    """Direct install without check - used from startup prompt"""
    dialog = xbmcgui.Dialog()
    try:
        _perform_install(new_version, url, dialog)
    except Exception as e:
        xbmc.log(f'[XStream Player] Direct update ERROR: {str(e)}', xbmc.LOGERROR)
        dialog.ok('XStream Player', _t(30405))


def check_and_install_update():
    """Main entry point: Check for update and prompt user (for Tools menu)"""
    xbmc.log('[XStream Player] Check update started', xbmc.LOGDEBUG)
    dialog = xbmcgui.Dialog()

    try:
        progress = xbmcgui.DialogProgress()
        progress.create('XStream Player', _t(30406))

        update_available, new_version, url = check_for_update()
        xbmc.log(
            f'[XStream Player] Update check: available={update_available}, version={new_version}',
            xbmc.LOGDEBUG,
        )

        progress.close()

        if not update_available:
            if new_version is None:
                dialog.ok('XStream Player', _t(30407))
            else:
                dialog.ok('XStream Player', _t(30408))
            return

        current = get_current_version()
        result = dialog.yesno(
            _t(30409),
            _t(30410, current, new_version)
        )
        if not result:
            return

        _perform_install(new_version, url, dialog)

    except Exception as e:
        xbmc.log(f'[XStream Player] Update ERROR: {str(e)}', xbmc.LOGERROR)
        import traceback
        xbmc.log(f'[XStream Player] Traceback: {traceback.format_exc()}', xbmc.LOGERROR)
        dialog.ok('XStream Player', _t(30411))


def silent_check_on_startup():
    """Background check on startup (if enabled in settings)"""
    addon = get_addon()
    check_interval = addon.getSetting('update_check_interval')

    # Settings values are localized (Croatian): Nikad | Pri pokretanju | Dnevno | Tjedno | Mjesečno
    if check_interval in ('Never', 'Nikad'):
        return

    last_check = addon.getSetting('last_update_check')
    today = time.strftime('%Y-%m-%d')

    if check_interval in ('Daily', 'Dnevno'):
        if last_check == today:
            return
    elif check_interval in ('Weekly', 'Tjedno'):
        if last_check:
            last_time = time.mktime(time.strptime(last_check, '%Y-%m-%d'))
            now_time = time.mktime(time.strptime(today, '%Y-%m-%d'))
            if (now_time - last_time) < (7 * 24 * 60 * 60):
                return
    elif check_interval in ('Monthly', 'Mjesečno'):
        if last_check:
            last_time = time.mktime(time.strptime(last_check, '%Y-%m-%d'))
            now_time = time.mktime(time.strptime(today, '%Y-%m-%d'))
            if (now_time - last_time) < (30 * 24 * 60 * 60):
                return
    # "On Startup" / "Pri pokretanju" always proceeds here

    update_available, new_version, url = check_for_update()

    if update_available:
        current = get_current_version()
        result = xbmcgui.Dialog().yesno(
            _t(30706),
            _t(30707, current, new_version),
            nolabel=_t(30708),
            yeslabel=_t(30709)
        )

        if result:
            # Update timestamp before install so failures don't cause immediate recheck
            addon.setSetting('last_update_check', today)
            do_direct_update_install(new_version, url)
            return
        else:
            addon.setSetting('update_available', 'true')
            addon.setSetting('update_version', new_version)

    addon.setSetting('last_update_check', today)


def get_available_versions():
    """Get list of all available version strings (newest first), for revert UI."""
    return [v['version'] for v in fetch_all_versions()]


def revert_to_version(version):
    """Revert to a specific older version."""
    filename = f'plugin.video.xstream-player-{version}.zip'
    url = _release_url(filename)

    dialog = xbmcgui.Dialog()
    result = dialog.yesno(
        'Revert Version',
        f'Downgrade to version {version}?\n\nThis will replace your current installation.'
    )
    if not result:
        return False

    return _perform_install(version, url, dialog, completion_title='Revert Complete')


def revert_version_menu():
    """Show menu to select version to revert to"""
    dialog = xbmcgui.Dialog()

    versions = get_available_versions()
    current = get_current_version()

    if not versions:
        dialog.notification('XStream Player', 'Could not fetch versions', xbmcgui.NOTIFICATION_ERROR)
        return

    older_versions = [v for v in versions if v != current]

    if not older_versions:
        dialog.ok('XStream Player', 'No older versions available to revert.')
        return

    selected = dialog.select(f'Revert to (current: {current})', older_versions)
    if selected == -1:
        return

    revert_to_version(older_versions[selected])


# Entry point for RunScript calls
if __name__ == '__main__':
    if len(sys.argv) > 1:
        action = sys.argv[1]
        if action == 'check':
            check_and_install_update()
        elif action == 'silent':
            silent_check_on_startup()
