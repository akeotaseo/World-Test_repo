To disable changelog go to Tools/Settings/Update

## V 1.1.5

- Fixed EPG crash in PVR - skip EPG export if file exists and is <4 hours old
- Added is_refreshing compatibility attribute to EPG class (fixes AttributeError)
- Combined PVR in Settings - option to use pvr client settings or addon Settings
- Added UTF-8 encoding headers to favorites.py, iptv.py, profiles.py, tmdb.py
- Added automatic cache cleanup - removes stale cache files older than 7 days at startup
- Added EPG fallback handling - tries alternative endpoint when auto-detected EPG URL fails
- Added user notification when EPG data fails to load
- Added M3U content validation - checks Content-Type, minimum size, and validates stream URLs
- Added full M3U catchup/replay support with template variable support
- Added restart message after PVR favorites operations (new groups/channels) - informs users that Kodi restart is required to see changes in PVR
- Updated all 16 language files with new translations
- Settings - PVR, added on/off toggle for favorites PVR, when off favorites PVR instance doesnt load on new restart