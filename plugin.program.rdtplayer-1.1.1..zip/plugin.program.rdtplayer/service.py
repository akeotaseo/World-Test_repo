# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()
api_key = ADDON.getSetting("api_key")

if api_key:
    xbmc.log(f"[DiamondService] API-Key mode OK (key length: {len(api_key)})", xbmc.LOGINFO)
else:
    xbmc.log("[DiamondService] No API key set!", xbmc.LOGWARNING)
