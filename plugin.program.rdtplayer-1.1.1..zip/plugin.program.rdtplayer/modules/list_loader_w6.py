import xbmc, xbmcgui, xbmcvfs, json, requests

URL_JSON = "https://uck.st/maglist_121925/master_list.json"
#
LOCAL_JSON = "special://profile/addon_data/plugin.program.rdtplayer/last_search_letters.json"

def load_movie_list(use_local: bool):
    data = None
    if use_local:
        xbmc.log("[RDTools] User selected LOCAL JSON list W6.", xbmc.LOGINFO)
        try:
            path = xbmcvfs.translatePath(LOCAL_JSON)
            f = xbmcvfs.File(path)
            content = f.read()
            f.close()
            data = json.loads(content) if content.strip() else []
        except Exception as e:
            xbmcgui.Dialog().ok("RD Tools", f"Failed to load local JSON list W6:\n{e}")
            xbmc.log(f"[RDTools] Local JSON list W6 error: {e}", xbmc.LOGERROR)
    else:
        xbmc.log("[RDTools] User selected REMOTE JSON list W6.", xbmc.LOGINFO)
        try:
            r = requests.get(URL_JSON, timeout=8)
            data = r.json() if r.ok else []
            if not r.ok:
                xbmcgui.Dialog().ok("RD Tools", f"Failed to load remote list W6 (HTTP {r.status_code})")
        except Exception as e:
            xbmcgui.Dialog().ok("RD Tools", f"Remote JSON list W6 failed:\n{e}")
            xbmc.log(f"[RDTools] Remote JSON list W6 error: {e}", xbmc.LOGERROR)
    return data or []
