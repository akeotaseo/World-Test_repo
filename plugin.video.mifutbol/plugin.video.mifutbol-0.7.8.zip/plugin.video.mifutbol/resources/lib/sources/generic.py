"""Fuente parametrizada: una entrada en sources.json = una web scrapeable.

Cada entrada tiene esta forma:

{
  "name": "mi_fuente",
  "type": "generic",
  "url":  "https://...",
  "headers": { "User-Agent": "Mozilla/5.0 ..." },
  "timeout": 10,
  "event_regex": "(?P<title>...)(?P<time>...)(?P<block>...)"
}

Convenciones del regex:
  - grupos nombrados: title, time, block (opcional: ids directo).
  - en 'block' basta con que aparezcan los hashes de 40 hex del evento;
    los extraemos aparte con otro regex.

Si la web no encaja en este patron, se crea un modulo .py propio.
"""

import re

ID_RE = re.compile(r"\b([0-9a-f]{40})\b", re.I)


def fetch_events(cfg):
    name = cfg.get("name", "generic")
    url = cfg["url"]
    headers = cfg.get("headers") or {}
    timeout = cfg.get("timeout", 10)
    event_regex = cfg["event_regex"]

    try:
        import requests
    except ImportError:
        raise RuntimeError("Falta script.module.requests para fuentes remotas")

    resp = requests.get(url, headers=headers, timeout=timeout)
    resp.raise_for_status()
    html = resp.text

    events = []
    for m in re.finditer(event_regex, html, re.S | re.I):
        parts = m.groupdict()
        title = (parts.get("title") or "").strip()
        tval = (parts.get("time") or "").strip()
        search_in = parts.get("block") or parts.get("ids") or m.group(0)
        ids = ID_RE.findall(search_in)
        if not ids:
            continue
        events.append({
            "title": title or "(sin titulo)",
            "time": tval or "--:--",
            "ids": list(dict.fromkeys(ids)),  # dedup preservando orden
            "source": name,
        })
    return events
