"""Fuente especifica de Markel Links.

Combina dos endpoints:
  /assets/links.json           -> lista de canales con URL acestream
  /assets/provider-order.json  -> patrones regex por competicion/provider

Devuelve items con estructura:
  {
    "title":   "M+ LALIGA 1",              # nombre del canal (sin OPCION N)
    "time":    "--:--",                    # no aplica, son canales lineales
    "ids":     ["hash1", "hash2", ...],    # acestream IDs del canal
    "provider":"Movistar+ LaLiga",         # categoria para agrupar
    "img":     "https://.../logo.png",     # logo del canal
    "source":  "markel",
  }
"""

import re

ID_RE = re.compile(r"[0-9a-f]{40}", re.I)
OPTION_RE = re.compile(r"\s*\(OPCI[OÓ]N\s*\d+\)\s*", re.I)

BASE = "https://www.markellinks.app"
DEFAULT_PROVIDER = "Otros"


def fetch_events(cfg):
    try:
        import requests
    except ImportError:
        raise RuntimeError("Falta script.module.requests")

    h = cfg.get("headers") or {}
    t = cfg.get("timeout", 10)

    def _get(path):
        r = requests.get(BASE + path, headers=h, timeout=t)
        r.raise_for_status()
        return r.json()

    items = _get("/assets/links.json")
    try:
        providers = _get("/assets/provider-order.json")
    except Exception:
        providers = []

    prov_compiled = []
    for p in providers:
        try:
            prov_compiled.append((p["name"], re.compile(p["pattern"], re.I)))
        except Exception:
            pass

    def classify(tags):
        for pname, prx in prov_compiled:
            if prx.search(tags):
                return pname
        return DEFAULT_PROVIDER

    channels = {}
    order = []

    for item in items:
        if not isinstance(item, dict):
            continue
        url_raw = str(item.get("url", ""))
        m = ID_RE.search(url_raw)
        if not m:
            continue
        ace_id = m.group(0).lower()

        title_raw = str(item.get("title", "")).strip()
        tags = str(item.get("tags", "")).strip().lower()
        channel = OPTION_RE.sub("", title_raw).strip() or title_raw or tags
        if not channel:
            continue

        if channel not in channels:
            channels[channel] = {
                "ids": [],
                "provider": classify(tags),
                "img": item.get("img"),
                "tags": tags,
            }
            order.append(channel)
        if ace_id not in channels[channel]["ids"]:
            channels[channel]["ids"].append(ace_id)

    name = cfg.get("name", "markel")
    return [
        {
            "title": ch,
            "time": "--:--",
            "ids": channels[ch]["ids"],
            "provider": channels[ch]["provider"],
            "img": channels[ch].get("img"),
            "source": name,
        }
        for ch in order
    ]
