"""Fuente: futbolenlatv.es.

Devuelve eventos (partidos) con:
  {
    "title":         "Bosnia - Rumania",
    "time":          "20:45",
    "competition":   "UEFA Nations League",
    "channel_names": ["DAZN (Ver en directo)", "DAZN App Gratis (Ver gratis)"],
    "source":        "futbolenlatv",
  }

Luego el matcher cruza channel_names con los canales de otras fuentes
(p.ej. markel) para asignar acestream IDs.
"""

import re

ROW_RE = re.compile(
    r'<tr(?:\s+class="(?P<cls>[^"]*)")?\s*>(?P<body>.*?)</tr>',
    re.S | re.I,
)
HEADER_LINK_RE = re.compile(
    r'<a[^>]*href="/competicion/[^"]+"[^>]*>\s*(?P<name>[^<]+?)\s*</a>',
    re.S | re.I,
)
HEADER_IMG_RE = re.compile(
    r'<img[^>]*(?:title|alt)="(?P<name>[^"]+)"', re.S | re.I,
)
MATCH_NAME_RE = re.compile(
    r'<meta\s+itemprop="name"\s+content="(?P<name>[^"]+)"\s*/?>',
    re.S | re.I,
)
MATCH_TIME_RE = re.compile(
    r'<td\s+class="hora\s*">\s*(?P<time>\d\d:\d\d)\s*</td>',
    re.S | re.I,
)
MATCH_START_RE = re.compile(
    r'<meta\s+itemprop="startDate"\s+content="(?P<ts>[^"]+)"\s*/?>',
    re.S | re.I,
)
CANAL_RE = re.compile(
    r'<li[^>]*title="(?P<name>[^"]+)"', re.S | re.I,
)


def _clean(text):
    # Decodificar entidades HTML basicas y limpiar espacios
    text = text.replace("&amp;", "&").replace("&#39;", "'").replace("&quot;", '"')
    text = text.replace("&nbsp;", " ")
    return re.sub(r"\s+", " ", text).strip()


def fetch_events(cfg):
    try:
        import requests
    except ImportError:
        raise RuntimeError("Falta script.module.requests")

    url = cfg.get("url", "https://www.futbolenlatv.es/")
    headers = cfg.get("headers") or {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"
        ),
    }
    timeout = cfg.get("timeout", 15)

    resp = requests.get(url, headers=headers, timeout=timeout)
    resp.raise_for_status()
    resp.encoding = resp.apparent_encoding or "utf-8"
    html = resp.text

    source_name = cfg.get("name", "futbolenlatv")
    events = []
    current_competition = None

    for m in ROW_RE.finditer(html):
        cls = (m.group("cls") or "").strip()
        body = m.group("body")

        if "cabeceraCompericion" in cls:
            hm = HEADER_LINK_RE.search(body) or HEADER_IMG_RE.search(body)
            if hm:
                current_competition = _clean(hm.group("name"))
            continue

        if cls:  # cabeceraTabla, estadisticas..., etc.
            continue

        nm = MATCH_NAME_RE.search(body)
        tm = MATCH_TIME_RE.search(body)
        if not nm or not tm:
            continue

        name = _clean(nm.group("name"))
        time_str = tm.group("time").strip()
        channel_names = [_clean(cm.group("name")) for cm in CANAL_RE.finditer(body)]
        # Descartar canales "fantasma"
        channel_names = [c for c in channel_names if c and c.lower() != "canal por confirmar"]

        start_match = MATCH_START_RE.search(body)
        start_iso = start_match.group("ts") if start_match else None

        events.append({
            "title": name,
            "time": time_str,
            "competition": current_competition or "Sin competicion",
            "channel_names": channel_names,
            "start_iso": start_iso,
            "source": source_name,
        })

    return events
