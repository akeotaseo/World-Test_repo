"""Fuente: neverland2.neocities.org.

Tabla HTML (exportada de Word) con filas tipo:
   <tr> <td>NOMBRE DEL CANAL</td> <td><a href="acestream://HASH">...</a></td> </tr>

Devuelve items estilo markel: title, provider ("Neverland2"), ids, source.
"""

import re

ID_RE = re.compile(r"acestream://([0-9a-f]{40})", re.I)
# El HTML viene de Word con mucho ruido (<span style=...>, <b>, <p>, <o:p>).
# Splitteamos por <tr para iterar filas, y dentro limpiamos tags.
ROW_SPLIT_RE = re.compile(r"<tr[^>]*>", re.I)
TAG_RE = re.compile(r"<[^>]+>")
WS_RE = re.compile(r"\s+")


def _clean(text):
    text = TAG_RE.sub(" ", text)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    return WS_RE.sub(" ", text).strip()


def fetch_events(cfg):
    try:
        import requests
    except ImportError:
        raise RuntimeError("Falta script.module.requests")

    url = cfg.get("url", "https://neverland2.neocities.org/")
    headers = cfg.get("headers") or {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36",
    }
    timeout = cfg.get("timeout", 10)

    resp = requests.get(url, headers=headers, timeout=timeout)
    resp.raise_for_status()
    resp.encoding = resp.apparent_encoding or "utf-8"
    html = resp.text

    name = cfg.get("name", "neverland2")
    provider = cfg.get("provider_label", "Neverland2")

    channels = {}
    order = []

    for row in ROW_SPLIT_RE.split(html):
        m_id = ID_RE.search(row)
        if not m_id:
            continue
        ace_id = m_id.group(1).lower()

        # Intentar extraer nombre del canal: primera celda <td>
        td_match = re.search(r"<td[^>]*>(.*?)</td>", row, re.S | re.I)
        channel_name = _clean(td_match.group(1)) if td_match else ""
        if not channel_name or "acestream://" in channel_name.lower():
            # fallback: todo el row limpio sin el enlace
            cleaned = _clean(row)
            channel_name = ID_RE.sub("", cleaned).replace("acestream://", "").strip() or "Canal Neverland2"

        if channel_name not in channels:
            channels[channel_name] = {"ids": []}
            order.append(channel_name)
        if ace_id not in channels[channel_name]["ids"]:
            channels[channel_name]["ids"].append(ace_id)

    return [
        {
            "title": ch,
            "time": "--:--",
            "ids": channels[ch]["ids"],
            "provider": provider,
            "tags": ch.lower(),
            "source": name,
        }
        for ch in order
    ]
