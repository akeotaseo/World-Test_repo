"""Fuente parametrizada para JSONs tipo lista.

Pensado para webs que exponen un endpoint JSON donde cada item lleva
un titulo y una URL 'acestream://...'. Ejemplo (markellinks.app):

    [
      { "title": "M+ LALIGA (OPCION 1)", "tags": "movistar laliga",
        "url": "acestream://045fd3d7..." },
      ...
    ]

Config en sources.json:

    {
      "name": "markel",
      "type": "json_links",
      "url": "https://www.markellinks.app/assets/links.json",
      "headers": { "User-Agent": "Mozilla/5.0 ..." },
      "items_path": "",            // opcional. "a.b" si el array esta anidado
      "title_field": "title",      // opcional, default "title"
      "url_field": "url",          // opcional, default "url"
      "group_field": "tags"        // opcional. Si existe, agrupa por ese campo.
                                   // Si no, quita "(OPCION N)" y agrupa.
    }
"""

import re

ID_RE = re.compile(r"[0-9a-f]{40}", re.I)
OPTION_RE = re.compile(r"\s*\(OPCI[OÓ]N\s*\d+\)\s*", re.I)


def _navigate(data, path):
    if not path:
        return data
    for part in path.split("."):
        data = data[part]
    return data


def fetch_events(cfg):
    try:
        import requests
    except ImportError:
        raise RuntimeError("Falta script.module.requests")

    url = cfg["url"]
    headers = cfg.get("headers") or {}
    timeout = cfg.get("timeout", 10)

    resp = requests.get(url, headers=headers, timeout=timeout)
    resp.raise_for_status()
    data = resp.json()

    items = _navigate(data, cfg.get("items_path", ""))
    if not isinstance(items, list):
        raise RuntimeError("items_path no apunta a una lista")

    title_field = cfg.get("title_field", "title")
    url_field = cfg.get("url_field", "url")
    group_field = cfg.get("group_field")
    name = cfg.get("name", "json_links")

    groups = {}
    order = []

    for item in items:
        if not isinstance(item, dict):
            continue
        raw_url = str(item.get(url_field, ""))
        m = ID_RE.search(raw_url)
        if not m:
            continue
        ace_id = m.group(0).lower()

        raw_title = str(item.get(title_field, "")).strip()
        if group_field and item.get(group_field):
            key = str(item[group_field]).strip()
        else:
            key = OPTION_RE.sub("", raw_title).strip() or raw_title or ace_id

        if key not in groups:
            groups[key] = []
            order.append(key)
        if ace_id not in groups[key]:
            groups[key].append(ace_id)

    return [
        {
            "title": key,
            "time": "--:--",
            "ids": groups[key],
            "source": name,
        }
        for key in order
    ]
