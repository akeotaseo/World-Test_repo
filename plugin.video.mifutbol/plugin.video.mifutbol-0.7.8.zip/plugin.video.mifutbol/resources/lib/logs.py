"""Utilidades para ver y compartir kodi.log desde dentro del addon."""

import xbmc
import xbmcgui
import xbmcvfs

MAX_SHOW_LINES = 300
MAX_UPLOAD_BYTES = 300_000  # paste.kodi.tv ~400 KB. Dejamos margen.


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[mifutbol] logs: {msg}", level)


def _find_log():
    for name in ("kodi.log", "kodi.old.log"):
        path = xbmcvfs.translatePath(f"special://logpath/{name}")
        if xbmcvfs.exists(path):
            return path, name
    return None, None


def _read_log(path):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception as e:
        return f"[error leyendo {path}: {e}]"


def _filter_relevant(text, max_lines):
    """Devuelve las lineas interesantes del log (mifutbol, errores, acestream)."""
    lines = text.splitlines()
    tail = lines[-15000:]
    keywords = (
        "[mifutbol]", " ERROR", " FATAL", "Traceback",
        "Exception", "acestream", "StartActivity", "StartAndroidActivity",
    )
    relevant = [ln for ln in tail if any(k in ln for k in keywords)]
    if not relevant:
        relevant = tail
    return relevant[-max_lines:]


def show_log():
    """Muestra las lineas relevantes de kodi.log en un TextViewer."""
    path, name = _find_log()
    if not path:
        xbmcgui.Dialog().ok("Pastu Furbo", "No encuentro kodi.log en special://logpath/")
        return
    text = _read_log(path)
    relevant = _filter_relevant(text, MAX_SHOW_LINES)
    body = "\n".join(relevant)
    header = f"Fichero: {name}  ({len(text)/1024:.0f} KB)\n----\n"
    xbmcgui.Dialog().textviewer("kodi.log (ultimas lineas filtradas)", header + body)


def upload_log():
    """Sube el log (filtrado + capado) a paste.kodi.tv y muestra la URL."""
    try:
        import requests
    except ImportError:
        xbmcgui.Dialog().ok("Pastu Furbo", "Falta script.module.requests")
        return

    path, name = _find_log()
    if not path:
        xbmcgui.Dialog().ok("Pastu Furbo", "No encuentro kodi.log en special://logpath/")
        return

    text = _read_log(path)
    relevant = _filter_relevant(text, max_lines=4000)
    body = "\n".join(relevant)

    # Capar por bytes (utf-8) por si aun pasa el limite
    while len(body.encode("utf-8", errors="ignore")) > MAX_UPLOAD_BYTES and relevant:
        relevant = relevant[len(relevant) // 10:]  # cortar el 10% mas antiguo
        body = "\n".join(relevant)

    header = (
        f"# kodi.log filtrado  (fichero: {name}, {len(text)/1024:.0f} KB)\n"
        f"# lineas en el paste: {len(relevant)}\n"
        "# ----\n"
    )
    payload = (header + body).encode("utf-8", errors="ignore")

    progress = xbmcgui.DialogProgress()
    progress.create("Pastu Furbo", f"Subiendo log ({len(payload)/1024:.0f} KB)...")
    progress.update(10)

    url = None
    error = None
    try:
        resp = requests.post(
            "https://paste.kodi.tv/documents",
            data=payload,
            headers={"User-Agent": "PastuFurbo-LogUploader"},
            timeout=20,
        )
        progress.update(80)
        if resp.status_code == 413:
            error = f"paste.kodi.tv dice que el log sigue siendo demasiado grande ({len(payload)/1024:.0f} KB)"
        else:
            resp.raise_for_status()
            key = resp.json().get("key")
            if key:
                url = f"https://paste.kodi.tv/{key}"
    except Exception as e:
        error = str(e)
        _log(f"upload KO: {e}", xbmc.LOGWARNING)
    finally:
        progress.close()

    if url:
        xbmcgui.Dialog().ok(
            "Log subido",
            f"Copia esta URL y pasasela al desarrollador:\n\n{url}",
        )
    else:
        xbmcgui.Dialog().ok(
            "Error subiendo",
            f"No he podido subir el log.\n\nDetalle: {error or 'respuesta vacia'}",
        )
