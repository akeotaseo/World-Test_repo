# -*- coding: utf-8 -*-
import xbmc, xbmcgui

def YouTube():
    choice = xbmcgui.Dialog().yesno('[B][COLOR red]YouTube[/COLOR][/B]', '[COLOR orange]Κανάλια & Λίστες απο το Πρόσθετο[CR][COLOR red]YouTube[/COLOR]',
                                    yeslabel='[COLOR red]YouTube[/COLOR]', nolabel='[COLOR orange]Whiskey Blues[/COLOR]')
    if choice == 1:
        Tube()


def Tube():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7)
    call = xbmcgui.Dialog().select('[B][COLOR red]YouTube[/COLOR][/B]', 
[
 'Moody Blues Lounge',
 'JAZZ & BLUES',
 'Dons Tunes',
 'Slow Blues/ Blues Ballads',
 '#bluesballads',
 'Sweet Soul Blues',
 'Jazz Haze'
 ])
 
    # Το Dialog().select επιστρέφει -1 αν ο χρήστης πατήσει Back/Cancel
    if call == -1:
        return
        
    # Καλούμε απευθείας τη συνάρτηση που αντιστοιχεί στη σειρά που πατήθηκε (0 έως 6)
    func = funcs[call]
    return func()


def click_1():
    Close()
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    xbmc.sleep(4000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?category_label=Moody%20Blues%20Lounge&q=Moody%20Blues%20Lounge&type=video")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    xbmc.sleep(2000)
    
def click_2():
    Close()
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    xbmc.sleep(4000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?category_label=JAZZ%20%26%20BLUES&q=JAZZ%20%26%20BLUES&type=video",)')
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    xbmc.sleep(2000)
    
def click_3():
    Close()
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    xbmc.sleep(4000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?category_label=Don%27s%20Tunes&q=Don%27s%20Tunes&type=video")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    xbmc.sleep(2000)


def click_4():
    Close()
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    xbmc.sleep(4000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?category_label=Slow%20Blues%2f%20Blues%20Ballads&q=Slow%20Blues%2f%20Blues%20Ballads&type=video")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    xbmc.sleep(2000)


def click_5():
    Close()
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    xbmc.sleep(4000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?category_label=%23bluesballads&q=%23bluesballads&type=video")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    xbmc.sleep(2000)


def click_6():
    Close()
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    xbmc.sleep(4000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?category_label=Sweet%20Soul%20Blues&q=Sweet%20Soul%20Blues&type=video")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    xbmc.sleep(2000)


def click_7():
    Close()
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    xbmc.sleep(4000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?category_label=Jazz%20Haze&q=Jazz%20Haze&type=video")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    xbmc.sleep(2000)


def Close():
    xbmc.executebuiltin('Dialog.Close(all,true)')

YouTube()
