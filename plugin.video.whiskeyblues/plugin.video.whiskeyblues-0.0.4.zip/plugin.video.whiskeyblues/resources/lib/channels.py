# -*- coding: utf-8 -*-
"""Channel list loader.

The list lives in a JSON file, so it can be edited without touching the code:

    [
      {"id": "UCxxxxxxxxxxxxxxxxxxxxxx", "name": "Optional name", "icon": "optional: http(s) url or full path"},
      {"id": "@SomeHandle"},
      {"id": "https://www.youtube.com/@SomeHandle"},
      ...
    ]

"id" is required and can be a channel id, an @handle or a channel URL. A missing "name" or "icon" is filled in from YouTube.
If a channels.json exists in the addon's userdata folder
(addon_data/plugin.video.kidstime/channels.json) it is used instead of the bundled one.
"""

import json
import os

from . import common

BUNDLED = os.path.join(common.ADDON_PATH, 'resources', 'channels.json')
USER = os.path.join(common.PROFILE, 'channels.json')


def _load(path):
    with open(path, 'r', encoding='utf-8-sig') as f:
        data = json.load(f)
    result = []
    for c in data:
        if not isinstance(c, dict):
            continue
        ref = c.get('id') or c.get('url') or c.get('handle')
        if ref:
            result.append(dict(c, id=ref))
    return result


def load():
    for path in (USER, BUNDLED):
        if os.path.isfile(path):
            try:
                channels = _load(path)
                common.log('channels loaded from {} ({})'.format(path, len(channels)))
                return channels
            except (OSError, ValueError) as exc:
                common.log('bad channels file {}: {}'.format(path, exc))
    return []
