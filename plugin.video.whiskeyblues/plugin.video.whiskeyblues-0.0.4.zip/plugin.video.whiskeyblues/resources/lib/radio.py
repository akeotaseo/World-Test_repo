# -*- coding: utf-8 -*-https://radiostreaming.ert.gr/ert-webjazz
# -*- coding: utf-8 -*-
import os
import xbmc
import xbmcgui
import xbmcvfs

# Κλείνει αμέσως το OSD/Σφάλμα στην εκκίνηση
xbmc.executebuiltin('Dialog.Close(all,true)')

def play_kosmos_jazz():
    # Το direct streaming URL ήχου της ΕΡΤ
    stream_url = "https://radiostreaming.ert.gr/ert-webjazz"
    
    # Δημιουργία απλού ListItem
    li = xbmcgui.ListItem('Kosmos Jazz')
    
    # -------------------------------------------------------------------------
    # ΑΠΟΛΥΤΗ ΔΙΟΡΘΩΣΗ ΓΙΑ ΤΟ ΕΙΚΟΝΙΔΙΟ (ΔΥΝΑΜΙΚΗ ΔΙΑΔΡΟΜΗ)
    # -------------------------------------------------------------------------
    # Βρίσκουμε αυτόματα τον φάκελο resources/lib/ όπου τρέχει αυτό το αρχείο
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Ανεβαίνουμε έναν φάκελο πάνω και μπαίνουμε στο resources/media/kosmosjazz.png
    # Αυτό δουλεύει 100% είτε το addon λέγεται kidstime είπε whiskeyblues!
    addon_dir = os.path.dirname(current_dir)
    real_icon_path = os.path.join(addon_dir, 'media', 'kosmosjazz.png')
    
    # Περνάμε την πραγματική διαδρομή στο ListItem
    li.setArt({'icon': real_icon_path, 'thumb': real_icon_path, 'poster': real_icon_path})
    # -------------------------------------------------------------------------
    
    # Δημιουργούμε τον player και ξεκινάμε το stream
    player = xbmc.Player()
    player.play(item=stream_url, listitem=li)
    
    # Δίνουμε χρόνο στο Kodi να ξεκινήσει το buffering (έως 5 δευτερόλεπτα)
    for _ in range(50):
        if player.isPlaying():
            break
        xbmc.sleep(100)
        
    # Κρατάμε το script ζωντανό στο παρασκήνιο με ασφάλεια
    while player.isPlaying():
        xbmc.sleep(1000)
