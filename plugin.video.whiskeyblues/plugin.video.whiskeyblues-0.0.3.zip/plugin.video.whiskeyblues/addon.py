# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import xbmc, xbmcgui
# import xbmc
import sys
from tulip.compat import parse_qsl
from xbmc import getInfoLabel
from resources.lib import whiskey


params = dict(parse_qsl(sys.argv[2].replace('?','')))

action = params.get('action')
url = params.get('url')

fp = getInfoLabel('Container.FolderPath')

if action is None:
    whiskey.Indexer().root(audio_only='audio' in fp)

elif action == 'addBookmark':
    from tulip import bookmarks
    bookmarks.add(url)

elif action == 'deleteBookmark':
    from tulip import bookmarks
    bookmarks.delete(url)

elif action == 'bookmarks':
    whiskey.Indexer().bookmarks()

elif action == 'videos':
    whiskey.Indexer().videos(url)

elif action == 'play':
    whiskey.Indexer().play(url)


elif action == 'episodes':
    whiskey.Indexer().episodes(url)



elif action == 'archive1':
    whiskey.Indexer().archive1()

elif action == 'archive2':
    whiskey.Indexer().archive2()

elif action == 'archive3':
    whiskey.Indexer().archive3()

elif action == 'archive4':
    whiskey.Indexer().archive4()

elif action == 'archive5':
    whiskey.Indexer().archive5()

# elif action == 'archive6':
    # whiskey.Indexer().archive6()
   

elif action == 'archive6':
    # whiskey.Indexer().archive6()
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.video.whiskeyblues/YouTube.py")')
###############
   
elif action == 'archive7':
    whiskey.Indexer().archive7()
    
elif action == 'archive8':
    whiskey.Indexer().archive8()

elif action == 'archive9':
    whiskey.Indexer().archive9()

elif action == 'archive10':
    whiskey.Indexer().archive10()
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.sleep(1000)
    # xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    # xbmc.sleep(1000)
    # xbmc.executebuiltin('PlayMedia("plugin://plugin.video.youtube/play/?video_id=PgWGOYnxSJg",playlist_type_hint=1)')
    # xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR red]YouTube[/COLOR]", sound=False, icon='special://home/addons/plugin.video.youtube/resources/media/icon.png')
    # xbmc.sleep(2000)
    

elif action == 'archive11':
    whiskey.Indexer().archive11()

elif action == 'archive12':
    whiskey.Indexer().archive12()
    
elif action == 'archive13':
    whiskey.Indexer().archive13()
    
elif action == 'archive14':
    whiskey.Indexer().archive14()

elif action == 'archive15':
    whiskey.Indexer().archive15()

elif action == 'archive16':
    whiskey.Indexer().archive16()

elif action == 'archive17':
    whiskey.Indexer().archive17()

elif action == 'archive18':
    whiskey.Indexer().archive18()
    
elif action == 'archive19':
    whiskey.Indexer().archive19()

elif action == 'archive20':
    whiskey.Indexer().archive20()

elif action == 'archive21':
    whiskey.Indexer().archive21()

elif action == 'archive22':
    whiskey.Indexer().archive22()

elif action == 'archive23':
    whiskey.Indexer().archive23()

elif action == 'archive24':
    whiskey.Indexer().archive24()



elif action == 'cache_clear':
    from tulip import cache
    cache.clear(withyes=False)
