# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
# import xbmc, xbmcgui
import json, re
from base64 import b64decode
from tulip import bookmarks, directory, client, cache, control, youtube
from tulip.compat import zip, iteritems
from youtube_resolver import resolve as yt_resolver


class Indexer:

    def __init__(self):

        self.list = []; self.data = []
        self.base_link = 'https://www.skaitv.gr'
        self.old_base = 'https://www.skai.gr'
        self.radio_base = 'http://www.skairadio.gr'
        self.yt1_channel = 'UCGr-rTYtP1m-r_-ncspdVQQ'
        self.yt2_channel = 'UCXOhnRJzBrQvHWpAPWyOQLQ'
        self.yt3_channel = 'UCQ4CYWLptlLlfiVnukaul6A'
        self.yt4_channel = 'UCkC2cDR39UCY6VMokkKQK5g'
        self.yt5_channel = 'UCLNfTiKDoxkxXGMe3R6hWPg'
###########################################################
        # self.yt6_channel = '    '
        self.yt7_channel = 'UCoTSCUHT0OA66Js0S-Ib4cw'
        self.yt8_channel = 'UCtR9W551g54iYiiHl7cVDDQ'
        self.yt9_channel = 'UCVc5O5-hxnMVCI2Wbvq4V9g'
        self.yt10_channel = 'UCNQK2LxQ35eK9h7Nnuh0vXw'
        self.yt11_channel = 'UCvnYUNQKWA5AYhrF1_OXmng'
        self.yt12_channel = 'UCh2eh40aEqKmXbRvGYC-aFA'
        self.yt13_channel = 'UCS6FiQ6WM3vRNe9Sz5rpqJA'
        self.yt14_channel = 'UCYY_YLVWFI_IZ51Eu6x9bgA'
        self.yt15_channel = 'UC9F8IZRbeuEVy08y6CqRYRw'
        self.yt16_channel = 'UCIltSH4uF9cRtizvUe3eEog'
        self.yt17_channel = 'UC509DGebPA7ZNGkkA2zQ7iw'
        self.yt18_channel = 'UC0F_QA80shnike2ZAq55Rcw'
        self.yt19_channel = 'UCtCtygf9FbsIcP67_JIUZBA'
        self.yt20_channel = 'UCARJ1_worg46zlhYsJgNYSA'
        # self.yt21_channel = 'UCQ29TCmt9x8-f3z7gNZVhAQ'
        # self.yt22_channel = 'UC46V9518VoWkIDeGaP4EDfg'
        # self.yt23_channel = 'UC9QSJuIBLUT2GbjgKymkTaQ'
        # self.yt24_channel = 'UCClAFTnbGditvz9_7_7eumw'
        self.yt_key = ('AIzaSyCPc7xY82ybv6FjUagTYG1Sn3iw057w6eE')
        self.tvshows_link = ''.join([self.base_link, '/shows/seires'])
        self.entertainment_link = ''.join([self.base_link, '/shows/psuchagogia'])
        self.news_link = ''.join([self.base_link, '/shows/enimerosi'])
        self.live_link = ''.join([self.base_link, '/live'])
        self.podcasts_link = ''.join([self.radio_base, '/shows?page=0'])
        self.play_link = 'http://videostream.skai.gr/'
        self.radio_link = 'https://skai.live24.gr/skai1003'

    def root(self, audio_only=False):

        self.list = [
            {
                'title': control.lang(101),
                'action': 'archive1',
                'icon': 'ytf1.png'
            }
            ,
            {
                'title': control.lang(102),
                'action': 'archive2',
                'icon': 'ytf2.png'
            }
            ,
            {
                'title': control.lang(103),
                'action': 'archive3',
                'icon': 'ytf3.png'
            }
            ,
            {
                'title': control.lang(104),
                'action': 'archive4',
                'icon': 'ytf4.png'
            }
            ,
            {
                'title': control.lang(105),
                'action': 'archive5',
                'icon': 'ytf5.png'
            }
            ,
            {
                'title': control.lang(106),
                'action': 'archive6',
                'icon': 'ytf6.png'
            }
            ,
            {
                'title': control.lang(107),
                'action': 'archive7',
                'icon': 'ytf7.png'
            }
                          ,
            {
                'title': control.lang(108),
                'action': 'archive8',
                'icon': 'ytf8.png'
            }
            ,
            {
                'title': control.lang(109),
                'action': 'archive9',
                'icon': 'ytf9.png'
            }
            ,
            {
                'title': control.lang(110),
                'action': 'archive10',
                'icon': 'ytf10.png'
            }
            ,
            {
                'title': control.lang(111),
                'action': 'archive11',
                'icon': 'ytf11.png'
            }
            ,
            {
                'title': control.lang(112),
                'action': 'archive12',
                'icon': 'ytf12.png'
            }
            ,
            {
                'title': control.lang(113),
                'action': 'archive13',
                'icon': 'ytf13.png'
            }
            ,
            {
                'title': control.lang(114),
                'action': 'archive14',
                'icon': 'ytf14.png'
            }
            ,
            {
                'title': control.lang(115),
                'action': 'archive15',
                'icon': 'ytf15.png'
            }
            ,
            {
                'title': control.lang(116),
                'action': 'archive16',
                'icon': 'ytf16.png'
            }
            ,
            {
                'title': control.lang(117),
                'action': 'archive17',
                'icon': 'ytf17.png'
            }
            ,
            {
                'title': control.lang(118),
                'action': 'archive18',
                'icon': 'ytf18.png'
            }
            ,
            {
                'title': control.lang(119),
                'action': 'archive19',
                'icon': 'ytf19.png'
            }
            ,
            {
                'title': control.lang(120),
                'action': 'archive20',
                'icon': 'ytp20.png'
            }
            # ,
            # {
                # 'title': control.lang(121),
                # 'action': 'archive21',
                # 'icon': 'ytp21.png'
            # }
            # ,
            # {
                # 'title': control.lang(122),
                # 'action': 'archive22',
                # 'icon': 'ytp22.png'
            # }
            # ,
            # {
                # 'title': control.lang(123),
                # 'action': 'archive23',
                # 'icon': 'ytp23.png'
            # }
             # ,
            # {
                # 'title': control.lang(124),
                # 'action': 'archive24',
                # 'icon': 'ytp24.png'
            # }
        ]

        if audio_only:

            self.list = [self.list[1]] + [self.list[3]]

        for item in self.list:

            cache_clear = {'title': 32009, 'query': {'action': 'cache_clear'}}
            item.update({'cm': [cache_clear]})

        directory.add(self.list, content='videos')

    def bookmarks(self):

        self.list = bookmarks.get()

        if self.list is None:
            return

        for i in self.list:
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['delbookmark'] = i['url']
            i.update({'cm': [{'title': 32502, 'query': {'action': 'deleteBookmark', 'url': json.dumps(bookmark)}}]})

        self.list = sorted(self.list, key=lambda k: k['title'].lower())

        directory.add(self.list, content='videos')

    def archive1(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt1_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')

    def archive2(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt2_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
        
    def archive3(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt3_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
        
    def archive4(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt4_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
        
    def archive5(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt5_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
        
    def archive6(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt6_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
        
    def archive7(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt7_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
    
    def archive8(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt8_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')   

    def archive9(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt9_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')        
     
    def archive10(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt10_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
        
    def archive11(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt11_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')  

    def archive12(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt12_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos') 

    def archive13(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt13_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')  

    def archive14(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt14_channel,)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')  
        
    def archive15(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt15_channel,)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')

    def archive16(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt16_channel,)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')

    def archive17(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt17_channel,)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')         
     
    def archive18(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt18_channel,)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')

    def archive19(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt19_channel,)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')          
    
    def archive20(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt20_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
    
    def archive21(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt21_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
        
    def archive22(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt22_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
        
    def archive23(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt23_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')
        
    def archive24(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).playlists, 2, self.yt24_channel)

        if self.list is None:
            return

        for i in self.list:
            i['title'] = client.replaceHTMLCodes(i['title'])
            i.update({'action': 'episodes'})
            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']
            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        control.sortmethods('title')

        directory.add(self.list, content='videos')


    def shows(self, url):

        self.list = cache.get(self.generic_listing, 24, url)

        if self.list is None:
            return

        for i in self.list:

            i.update({'action': 'episodes'})

            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']

            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        directory.add(self.list, content='videos')

    def pod_listing(self, url):

        html = client.request(url)

        listing = client.parseDOM(html, 'div', attrs={'class': 'row border-bottom pt-4 m-0 show-item'})

        nexturl = re.sub(r'\d(?!\d)', lambda x: str(int(x.group(0)) + 1), url)

        for item in listing:

            title = client.parseDOM(item, 'h3')[0].replace('&#039;', '\'')
            image = ''.join([self.radio_base, client.parseDOM(item, 'img', ret='src')[0]])
            url = ''.join([self.radio_base, client.parseDOM(item, 'a', ret='href')[0]])

            self.list.append(
                {
                    'title': title, 'image': image, 'url': url, 'nextaction': 'podcasts', 'next': nexturl,
                    'nextlabel': 32500
                }
            )

        return self.list

    def podcasts(self, url=None):

        if url is None:
            url = self.podcasts_link

        self.list = cache.get(self.pod_listing, 24, url)

        if self.list is None:
            return

        for i in self.list:

            i.update({'action': 'episodes'})

            bookmark = dict((k, v) for k, v in iteritems(i) if not k == 'next')
            bookmark['bookmark'] = i['url']

            i.update({'cm': [{'title': 32501, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}]})

        directory.add(self.list, content='music')

    def pod_episodes(self, url):

        html = client.request(url)

        select = client.parseDOM(html, 'div', attrs={'class': 'col-8 col-sm-4 p-0'})[0]
        image = re.search(r'background-image: url\("(.+?)"\)', html).group(1)

        pods = re.findall(r'(<option.+?option>)', select, re.S)

        for pod in pods:

            date = re.search(r'(\d{2}/\d{2}/\d{4})', pod).group(1)
            title = ' - '.join([client.parseDOM(html, 'h2', attrs={'class': 'mb-3.+?'})[0], date])
            url = ''.join([self.radio_base, re.search(r'data-url = "([\w\-/]+)"', pod).group(1)])

            self.list.append({'title': title, 'image': image, 'url': url})

        return self.list

    def episodes(self, url):

        if self.base_link in url:
            self.list = cache.get(self.episodes_listing, 3, url)
        elif self.radio_base in url:
            self.list = cache.get(self.pod_episodes, 3, url)
        else:
            self.list = cache.get(youtube.youtube(key=self.yt_key).playlist, 3, url)

        if self.list is None:

            return

        for i in self.list:

            i.update({'action': 'play', 'isFolder': 'False'})

        directory.add(self.list, content='videos')

    def video_listing(self, url):

        html = client.request(url)

        try:
            nexturl = ''.join(
                [
                    self.old_base, '/videos',
                    client.parseDOM(html, 'a', attrs={'rel': 'next'}, ret='href')[0].replace('&amp;', '&')
                ]
            )
        except IndexError:
            nexturl = None

        video_list = client.parseDOM(html, 'div', attrs={'class': 'videoItem cell'}, ret='data-video-url')
        thumbnails = client.parseDOM(html, 'div', attrs={'class': 'videoItem cell'}, ret='data-video-poster')
        titles = client.parseDOM(html, 'div', attrs={'class': 'videoItem cell'}, ret='data-video-name')
        dates = client.parseDOM(html, 'div', attrs={'class': 'videoItem cell'}, ret='data-video-date')

        listing = list(zip(titles, dates, thumbnails, video_list))

        for title, date, image, video in listing:

            title = client.replaceHTMLCodes(title)

            label = ''.join([title, ' ', '(', date, ')'])

            self.list.append(
                {
                    'title': label, 'image': image, 'url': video, 'next': nexturl, 'nextlabel': 32500,
                    'nextaction': 'videos'
                }
            )

        return self.list

    def videos(self, url):

        self.list = cache.get(self.video_listing, 3, url)

        if self.list is None:
            return

        for i in self.list:

            i.update({'action': 'play', 'isFolder': 'False'})

        directory.add(self.list)

    def latest(self):

        self.list = cache.get(youtube.youtube(key=self.yt_key).videos, 1, self.yt_channel, False, 2)

        if self.list is None:
            return

        self.list = [i for i in self.list if int(i['duration']) > 60]

        for i in self.list:
            i.update({'action': 'play', 'isFolder': 'False'})

        directory.add(self.list)

    
    def play(self, url):

        resolved = self.resolve(url)

        if 'youtu' in resolved:
            resolved = self.yt_session(resolved)

        if isinstance(resolved, tuple):

            stream, plot = resolved
            meta = {'plot': plot}

        else:

            stream = resolved
            meta = None

        icon = None

        if url == self.radio_link:

            meta = {'title': 'Skai Radio 100.3FM'}

        elif url == self.live_link:

            meta = {'title': 'Skai Live TV'}
            icon = control.icon()

        dash = ('dash' in stream or '.mpd' in stream or 'm3u8' in stream) and control.kodi_version() >= 18.0

        directory.resolve(
            url=stream, meta=meta, dash=dash, icon=icon,
            mimetype='application/vnd.apple.mpegurl' if 'm3u8' in stream else None,
            manifest_type='hls' if '.m3u8' in stream else None
        )

    def generic_listing(self, url):

        html = client.request(url)

        if url == self.news_link:
            new = 'row m-0 listrow new-videos'
            new_items = 'col-12 pl-0 pr-0 list1 list-item color_enimerosi'
            archive = 'row m-0 listrow s234 '
            archived_items = 'col-12 pl-0 pr-0 list1 list-item color_enimerosi'
        elif url == self.entertainment_link:
            new = 'row  listrow list2 '
            new_items = 'd-none d-md-block col-md-4 listimg color_psuchagogia'
            archive = 'row  listrow list2 s234  '
            archived_items = 'd-none d-md-block col-md-3 listimg color_psuchagogia'
        else:
            new = 'row  listrow list2 '
            new_items = 'd-none d-md-block col-md-4 listimg color_seires'
            archive = 'row  listrow list2 s234  '
            archived_items = 'd-none d-md-block col-md-3 listimg color_seires'

        div = client.parseDOM(html, 'div', attrs={'class': new})[0]

        listing = client.parseDOM(div, 'div', attrs={'class': new_items})

        for item in listing:

            title = client.parseDOM(item, 'h3')[0]
            image = client.parseDOM(item, 'img', ret='src')[0]

            url = ''.join([self.base_link, client.parseDOM(item, 'a', ret='href')[0]])

            self.list.append({'title': title, 'url': url, 'image': image})

        if 's234' in html:

            div = client.parseDOM(html, 'div', attrs={'class': archive})[0]
            items = client.parseDOM(div, 'div', attrs={'class': archived_items})

            for item in items:

                title = ' - '.join([client.parseDOM(item, 'h3')[0], control.lang(32013)])
                image = client.parseDOM(item, 'img', ret='src')[0]

                url = ''.join([self.base_link, client.parseDOM(item, 'a', ret='href')[0]])

                self.list.append({'title': title, 'url': url, 'image': image})

        return self.list

    def episodes_listing(self, url):

        html = client.request(url)

        div = client.parseDOM(html, 'div', attrs={'class': 'row  listrow list2 ?'})[0]

        listing = client.parseDOM(div, 'div', attrs={'class': '.+?list-item  color.+?'})

        for item in listing:

            title = client.parseDOM(item, 'h3')[0].replace('<br/>', ' ').replace('<br>', ' ')
            image = client.parseDOM(item, 'img', ret='src')[0]

            url = ''.join([self.base_link, client.parseDOM(item, 'a', ret='href')[0]])

            self.list.append({'title': title, 'url': url, 'image': image})

        return self.list

    def resolve(self, url):

        if url == self.live_link:

            html = client.request(self.live_link)

            json_ = re.search(r'var data = ({.+?});', html).group(1)

            json_ = json.loads(json_)

            return json_['now']['livestream']

        elif len(url) == 11:

            link = self.yt_session(url)

            return link

        elif 'episode' in url:

            html = client.request(url)

            if url.startswith(self.radio_base):

                url = re.search(r'["\'](.+?\.mp3)["\']', html).group(1)

                return url

            else:

                json_ = re.search(r'var data = ({.+?});', html).group(1)

                json_ = json.loads(json_)

                url = ''.join([self.play_link, json_['episode'][0]['media_item_file'], '.m3u8'])

                plot = client.stripTags(json_['episode'][0]['descr'])

                return url, plot

        else:

            return url

    @staticmethod
    def yt_session(link):

        streams = yt_resolver(link)

        try:
            addon_enabled = control.addon_details('inputstream.adaptive').get('enabled')
        except KeyError:
            addon_enabled = False

        if not addon_enabled:

            streams = [s for s in streams if 'mpd' not in s['title']]

        stream = streams[0]['url']
         
        return stream
        


