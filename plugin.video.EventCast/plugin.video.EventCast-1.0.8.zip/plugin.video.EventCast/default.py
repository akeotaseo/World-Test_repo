# -*- coding: utf-8 -*-
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import sys
import os
import urllib.request
import urllib.parse

addon = xbmcaddon.Addon()
handle = int(sys.argv[1])
BASE_URL = sys.argv[0]

# ==================================================
# CONFIGURACIÓN
# ==================================================
REMOTE_URL = "https://gist.github.com/sapatilhas/92f5a8a84761be54c3c9c20d540d20c0/raw/partidos.txt"

# ==================================================
# PATHS Y RECURSOS
# ==================================================
addon_path = addon.getAddonInfo("path")
profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
cache_file = os.path.join(profile, "events.txt")
GENERIC_LOGO = os.path.join(addon_path, "resources", "icon.png")
GENERIC_FANART = os.path.join(addon_path, "resources", "fanart.jpg")

os.makedirs(profile, exist_ok=True)

# ==================================================
# LÓGICA DE DATOS
# ==================================================
def update_remote():
    try:
        req = urllib.request.Request(REMOTE_URL, headers={'User-Agent': 'Mozilla/5.0'})
        data = urllib.request.urlopen(req, timeout=10).read().decode("utf-8")
        with open(cache_file, "w", encoding="utf-8") as f:
            f.write(data)
        return True
    except Exception as e:
        xbmc.log("Error actualizando lista: " + str(e), xbmc.LOGERROR)
        return False

def read_events():
    events = []
    if not os.path.exists(cache_file):
        if not update_remote(): return events

    with open(cache_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or "|" not in line: continue
            p = line.split("|")
            if len(p) == 4:
                events.append({"league": p[0], "time": p[1], "match": p[2], "url": p[3]})
    return events

# ==================================================
# ACCIONES DE REPRODUCCIÓN Y CARGA
# ==================================================
def play_now(ace_id):
    """Lanza Horus sin que Kodi interfiera en la reproducción"""
    path = f"plugin://script.module.horus/?action=play&id={ace_id}"
    xbmc.executebuiltin(f"RunPlugin({path})")

def play_manual_acestream():
    link = xbmcgui.Dialog().input("Pega el enlace AceStream (acestream://...)")
    if link and link.startswith("acestream://"):
        ace_id = link.replace("acestream://", "").strip()
        play_now(ace_id)
    elif link:
        xbmcgui.Dialog().notification("Error", "Enlace no válido", xbmcgui.NOTIFICATION_ERROR)

def load_txt_from_url():
    url = xbmcgui.Dialog().input("Introduce la URL del TXT")
    if url:
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            data = urllib.request.urlopen(req, timeout=10).read().decode("utf-8")
            with open(cache_file, "w", encoding="utf-8") as f:
                f.write(data)
            xbmcgui.Dialog().notification("Éxito", "Lista cargada", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except:
            xbmcgui.Dialog().notification("Error", "No se pudo cargar", xbmcgui.NOTIFICATION_ERROR)

def load_txt_local():
    path = xbmcgui.Dialog().browse(1, "Selecciona tu partidos.txt", "files", ".txt")
    if path:
        try:
            with xbmcvfs.File(path) as f:
                data = f.read()
            with open(cache_file, "w", encoding="utf-8") as out:
                out.write(data)
            xbmcgui.Dialog().notification("Éxito", "Archivo cargado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except:
            xbmcgui.Dialog().notification("Error", "Fallo al leer archivo", xbmcgui.NOTIFICATION_ERROR)

# ==================================================
# MENÚS
# ==================================================
def main_menu():
    # Opción de reproducción manual
    li_manual = xbmcgui.ListItem("[COLOR yellow]🔗 REPRODUCIR ENLACE MANUAL[/COLOR]")
    xbmcplugin.addDirectoryItem(handle, f"{BASE_URL}?action=play_manual", li_manual, False)

    # Agrupar por Ligas
    events = read_events()
    leagues = {}
    for e in events:
        leagues.setdefault(e["league"], []).append(e)

    for league in sorted(leagues.keys()):
        count = len(leagues[league])
        li = xbmcgui.ListItem(f"[B]{league}[/B] [COLOR lightblue]({count})[/COLOR]")
        li.setArt({"thumb": GENERIC_LOGO, "icon": GENERIC_LOGO, "fanart": GENERIC_FANART})
        url = f"{BASE_URL}?action=list_league&league={urllib.parse.quote(league)}"
        xbmcplugin.addDirectoryItem(handle, url, li, True)

    # Ajustes
    li_tools = xbmcgui.ListItem("[COLOR grey][⚙️ HERRAMIENTAS Y AJUSTES][/COLOR]")
    xbmcplugin.addDirectoryItem(handle, f"{BASE_URL}?action=tools_menu", li_tools, True)
    
    xbmcplugin.endOfDirectory(handle)

def tools_menu():
    options = [
        ("🔄 Forzar actualización (Gist)", "force_update"),
        ("📂 Cargar archivo .txt local", "load_local"),
        ("🌐 Cargar .txt desde URL", "load_url"),
        ("↩️ Restaurar lista original", "reset_default")
    ]
    for label, act in options:
        li = xbmcgui.ListItem(label)
        xbmcplugin.addDirectoryItem(handle, f"{BASE_URL}?action={act}", li, False)
    xbmcplugin.endOfDirectory(handle)

def list_events(league_name):
    # Cambiamos a 'files' para que Kodi no aplique lógica de video automática
    xbmcplugin.setContent(handle, 'files')
    events = read_events()
    filtered = [e for e in events if e["league"] == league_name]
    
    for e in sorted(filtered, key=lambda x: x["time"]):
        time_label = f"[COLOR green]{e['time']}[/COLOR]" if "LIVE" in e['time'].upper() else f"[COLOR gold]{e['time']}[/COLOR]"
        li = xbmcgui.ListItem(label=f"{time_label} | [B]{e['match']}[/B]")
        
        ace_id = e['url'].replace("acestream://", "").strip()
        # La URL ahora apunta a nuestro router interno 'play_now'
        url_repro = f"{BASE_URL}?action=play_now&id={ace_id}"
        
        li.setInfo('video', {'title': e['match'], 'plot': f"Fuente: {e['league']}"})
        li.setArt({"thumb": GENERIC_LOGO, "icon": GENERIC_LOGO})
        
        # Folder=False indica que es una acción final
        xbmcplugin.addDirectoryItem(handle, url_repro, li, False)
        
    xbmcplugin.endOfDirectory(handle)

# ==================================================
# ROUTER
# ==================================================
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get('action')

if not action:
    main_menu()
elif action == 'list_league':
    list_events(params.get('league'))
elif action == 'play_now':
    play_now(params.get('id'))
elif action == 'tools_menu':
    tools_menu()
elif action == 'play_manual':
    play_manual_acestream()
elif action == 'force_update':
    if update_remote():
        xbmcgui.Dialog().notification("Éxito", "Lista actualizada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")
elif action == 'load_local':
    load_txt_local()
elif action == 'load_url':
    load_txt_from_url()
elif action == 'reset_default':
    if os.path.exists(cache_file): os.remove(cache_file)
    update_remote()
    xbmc.executebuiltin("Container.Refresh")