from urllib.parse import urlencode, parse_qsl, unquote, urlparse
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
import re, sys, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ICON = Addon().getAddonInfo('icon')
homeweb = 'https://watch.rkplayer.xyz'
UA = 'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/605.1.15 EdgA/133.0.0.0'
def addDir(title, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=20, max_age=luu, headers={'user-agent': UA, 'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        u = 'https://api.rkdata.xyz/v1/caheo/home.html'
        r = getlink(u, u, 400)
        kq = r.json()['data']['lives']
        for v in kq:
            for k in v['matchs']:
                timeShort = k['timeShort']
                home = k['home']['name']
                away = k['away']['name']
                blv = k['blv']['name']
                status = k['status']
                tg = f"[COLOR red]{timeShort}[/COLOR]" if status==1 else timeShort
                mau = f"[COLOR yellow]{home} vs {away}[/COLOR]"
                tenm = f"{tg} {mau} - {blv}" if blv else f"{tg} {home} vs {away}"
                addDir(tenm, 'list_caheo', idck=k['id'], name=tenm)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'list_caheo':
        u = f"{homeweb}/v1/caheo/{params['idck']}.html"
        r = getlink(u, u, 1000)
        s = re.findall(r',name:"(.*?)",url:"(.*?)"', r.text)
        for v in s:
            if 'm3u8' in v[1] or 'flv' in v[1]:
                tenm = f'{v[0]} - {params["name"]}'
                addDir(tenm, 'play', id=v[1], is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play':
        play_item = xbmcgui.ListItem(offscreen=True)
        linkplay = re.sub(r'\s+', '%20', params['id'].strip(), flags=re.UNICODE)
        hdr = f'verifypeer=false&User-Agent={unquote(UA)}&Referer={referer(homeweb)}'
        if 'm3u8' in linkplay:
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
            play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        else:
            linkplay = f'{linkplay}|{hdr}'
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])