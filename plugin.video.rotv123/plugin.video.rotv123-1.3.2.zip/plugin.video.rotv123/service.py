# -*- coding: utf-8 -*-
import os
import json
import time
import urllib.request
import xbmc
import xbmcvfs
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CACHE_FILE = os.path.join(PROFILE, 'epg_cache.json')

ACCKEY = "45sHMMCSEc"
BASE_URL = "https://api.cinemagia.ro/programTv/nowOnTv"
USER_AGENT = "Mozilla/5.0"


def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=10) as r:
        return r.read()


def load_mapping():
    path = xbmcvfs.translatePath(
        ADDON.getAddonInfo('path') + '/resources/mapping.json'
    )
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return [p["id"] for p in data.get("posturi", [])]


def fetch_station(station_id):
    try:
        url = f"{BASE_URL}?acckey={ACCKEY}&station_id={station_id}"
        raw = get(url)
        payload = json.loads(raw.decode("utf-8"))
        return station_id, payload
    except Exception:
        return station_id, None


def run():
    if not os.path.exists(PROFILE):
        os.makedirs(PROFILE)

    station_ids = load_mapping()

    cache = {
        "ts": time.time(),
        "data": {}
    }

    with ThreadPoolExecutor(max_workers=4) as ex:
        results = ex.map(fetch_station, station_ids)

    for sid, payload in results:
        if payload:
            cache["data"][sid] = payload

    with open(CACHE_FILE, 'w', encoding='utf-8') as f:
        json.dump(cache, f)

    xbmc.log("Rotv123: Background EPG prefetch complete", xbmc.LOGINFO)


if __name__ == "__main__":
    run()
