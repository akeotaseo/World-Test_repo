# -*- coding: utf-8 -*-
import sys
import urllib.parse
import urllib.request
import re
import json
import time
import os
import html as html_lib
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
import xbmcvfs

# ==============================
# CONFIG
# ==============================
URL = sys.argv[0]
HANDLE = int(sys.argv[1])
BASE_URL = 'https://rotv123.com'

CINEMAGIA_ACCKEY = '45sHMMCSEc'
CINEMAGIA_NOW_API = 'https://api.cinemagia.ro/programTv/nowOnTv'

USER_AGENT = 'Mozilla/5.0'

# Threading
PREFETCH_WORKERS = 4

# Cache (RAM)
_EPG_CACHE = {}  # station_id -> {"expire": float_epoch, "data": info_dict}

# Cache (DISK)
ADDON = xbmcaddon.Addon()
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CACHE_FILE = os.path.join(PROFILE_DIR, 'epg_cache.json')

# Mapping cache
_MAPPING = None


# ==============================
# HTTP
# ==============================
def get_data(url):
    if not url.startswith('http'):
        url = urllib.parse.urljoin(BASE_URL + '/', url)

    req = urllib.request.Request(url)
    req.add_header('User-Agent', USER_AGENT)

    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            return response.read()
    except Exception:
        return None


# ==============================
# UTILS
# ==============================
def clean_name(text):
    """Normalizeaza numele pentru a face match intre site si mapping clean_key."""
    if not text:
        return ""
    text = text.lower()
    text = re.sub(r'\.ro|\.com|\.tv|\bhd\b|\bsd\b|\bfhd\b|romania|online', '', text)
    text = re.sub(r'[^a-z0-9]', '', text)
    return text.strip()


def _fmt_time_range(start_iso, stop_iso):
    try:
        s = datetime.fromisoformat(start_iso).strftime('%H:%M')
        e = datetime.fromisoformat(stop_iso).strftime('%H:%M')
        return f"{s}–{e}"
    except Exception:
        return ""


def _pick_now_next(shows):
    active = None
    future = None
    for sh in shows or []:
        if sh.get('tense') == 'active' and not active:
            active = sh
        elif sh.get('tense') == 'future' and not future:
            future = sh
        if active and future:
            break
    return active, future


def _safe_int(x, default=0):
    try:
        return int(float(x))
    except Exception:
        return default


# ==============================
# PROGRESS BAR
# ==============================
def _progress_bar(percent, length=12):
    p = _safe_int(percent, 0)
    if p < 0:
        p = 0
    if p > 100:
        p = 100

    if p < 70:
        color = "lime"
    elif p < 90:
        color = "orange"
    else:
        color = "red"

    filled = int(round((p / 100.0) * length))
    if filled < 0:
        filled = 0
    if filled > length:
        filled = length

    bar = "█" * filled + "░" * (length - filled)
    return f"[COLOR {color}]{bar}[/COLOR] [COLOR white]{p}%[/COLOR]"


# ==============================
# BUILD PLOT
# ==============================
def build_epg_plot(info):
    """
    Plot compact fara descriere, cu bara progres colorata.
    """
    if not info:
        return "EPG indisponibil", ""

    now_title = (info.get("now_title") or "").strip()
    now_time = (info.get("now_time") or "").strip()
    now_percent = info.get("now_percent", 0)

    next_title = (info.get("next_title") or "").strip()
    next_time = (info.get("next_time") or "").strip()

    if not now_title:
        return "EPG indisponibil", ""

    progress = _progress_bar(now_percent)

    C_GOLD = "FFFFD700"
    C_SILVER = "FFCCCCCC"
    C_TIME = "FF7EC8FF"

    lines = []
    l1 = f"[B][COLOR {C_GOLD}]ACUM[/COLOR][/B]"
    if now_time:
        l1 += f"  [COLOR {C_TIME}]{now_time}[/COLOR]"
    lines.append(l1)
    lines.append(progress)
    lines.append(f"[B]{now_title}[/B]")

    if next_title:
        lines.append("")
        l2 = f"[B][COLOR {C_SILVER}]URM[/COLOR][/B]"
        if next_time:
            l2 += f"  [COLOR {C_TIME}]{next_time}[/COLOR]"
        lines.append(l2)
        lines.append(next_title)

    plot = "[CR]".join(lines)

    tagline = f"ACUM: {now_title}"
    if next_title:
        tagline += f" → URM: {next_title}"

    return plot, tagline


# ==============================
# DISK CACHE
# ==============================
def _ensure_profile_dir():
    try:
        if not xbmcvfs.exists(PROFILE_DIR):
            xbmcvfs.mkdirs(PROFILE_DIR)
    except Exception:
        pass


def _read_disk_cache():
    """
    Returns dict station_id -> {"expire": float_epoch, "data": info_dict}
    """
    try:
        if not xbmcvfs.exists(CACHE_FILE):
            return {}
        f = xbmcvfs.File(CACHE_FILE)
        raw = f.read()
        f.close()
        if not raw:
            return {}
        return json.loads(raw)
    except Exception:
        return {}


def _write_disk_cache(cache_dict):
    try:
        _ensure_profile_dir()
        f = xbmcvfs.File(CACHE_FILE, 'w')
        f.write(json.dumps(cache_dict, ensure_ascii=False))
        f.close()
    except Exception:
        pass


def _disk_cache_get(station_id):
    cache = _read_disk_cache()
    entry = cache.get(str(station_id))
    if not entry:
        return None
    try:
        if float(entry.get("expire", 0)) <= time.time():
            return None
    except Exception:
        return None
    return entry.get("data")


def _disk_cache_set(station_id, expire_epoch, info):
    cache = _read_disk_cache()
    cache[str(station_id)] = {"expire": float(expire_epoch), "data": info}
    _write_disk_cache(cache)


# ==============================
# LOAD MAPPING
# ==============================
def load_mapping():
    """
    mapping.json format:
    {"posturi":[{"id":"1","displayName":"PRO TV","clean_key":"protv"}, ...]}
    returns dict: clean_key -> station_id (string)
    """
    global _MAPPING
    if _MAPPING is not None:
        return _MAPPING

    try:
        addon_path = ADDON.getAddonInfo('path')
        mapping_path = xbmcvfs.translatePath(os.path.join(addon_path, 'resources', 'mapping.json'))

        f = xbmcvfs.File(mapping_path)
        raw = f.read()
        f.close()

        data = json.loads(raw) if raw else {}
        _MAPPING = {p.get("clean_key"): p.get("id") for p in data.get("posturi", []) if p.get("clean_key") and p.get("id")}
        return _MAPPING
    except Exception as e:
        xbmc.log(f"Rotv123: mapping.json load error: {e}", xbmc.LOGERROR)
        _MAPPING = {}
        return _MAPPING


# ==============================
# DYNAMIC TTL (BY STOP)
# ==============================
def _compute_expire_epoch(stop_iso, fallback_ttl=120):
    now = time.time()
    # clamp TTL between 30s and 2h
    min_ttl = 30
    max_ttl = 7200
    buffer = 15

    if stop_iso:
        try:
            stop_dt = datetime.fromisoformat(stop_iso)
            stop_ts = stop_dt.timestamp()
            ttl = int(stop_ts - now + buffer)
            if ttl < min_ttl:
                ttl = min_ttl
            if ttl > max_ttl:
                ttl = max_ttl
            return now + ttl
        except Exception:
            pass

    ttl = fallback_ttl
    if ttl < min_ttl:
        ttl = min_ttl
    if ttl > max_ttl:
        ttl = max_ttl
    return now + ttl


# ==============================
# LOAD EPG PER STATION (uses RAM + disk cache)
# ==============================
def load_epg_by_station_id(station_id):
    if not station_id:
        return None

    station_id = str(station_id)
    now = time.time()

    # 1) RAM cache
    entry = _EPG_CACHE.get(station_id)
    if entry and float(entry.get("expire", 0)) > now:
        return entry.get("data")

    # 2) Disk cache
    disk = _disk_cache_get(station_id)
    if disk:
        # populate RAM with a short safety TTL (keep disk as source of truth)
        # Note: disk entry already validated (not expired)
        _EPG_CACHE[station_id] = {"expire": now + 30, "data": disk}
        return disk

    # 3) Fetch from API
    url = f"{CINEMAGIA_NOW_API}?acckey={CINEMAGIA_ACCKEY}&station_id={station_id}"
    raw = get_data(url)
    if not raw:
        return None

    try:
        payload = json.loads(raw.decode("utf-8", errors="ignore"))
    except Exception:
        return None
    if not payload:
        return None

    item = payload[0] if isinstance(payload, list) else payload
    shows = item.get("shows") or []
    active, future = _pick_now_next(shows)
    if not active:
        return None

    now_time = _fmt_time_range(active.get("start"), active.get("stop"))
    next_time = _fmt_time_range(future.get("start"), future.get("stop")) if future else ""

    info = {
        "now_title": (active.get("title") or "").strip(),
        "now_time": now_time,
        "now_percent": active.get("percentToComplete", 0),
        "next_title": (future.get("title") or "").strip() if future else "",
        "next_time": next_time,
    }

    expire_epoch = _compute_expire_epoch(active.get("stop"), fallback_ttl=120)

    # update caches
    _EPG_CACHE[station_id] = {"expire": expire_epoch, "data": info}
    _disk_cache_set(station_id, expire_epoch, info)

    return info


# ==============================
# PREFETCH (parallel, blocking but fast)
# ==============================
def prefetch_epg_station_ids(station_ids, max_workers=4):
    uniq = []
    seen = set()
    for sid in station_ids:
        if not sid:
            continue
        sid = str(sid)
        if sid in seen:
            continue
        seen.add(sid)
        uniq.append(sid)

    if not uniq:
        return

    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = [ex.submit(load_epg_by_station_id, sid) for sid in uniq]
        for _ in as_completed(futures):
            pass


# ==============================
# MAIN MENU
# ==============================
def main_menu():
    data = get_data(BASE_URL)
    if not data:
        return

    page_html = data.decode('utf-8', errors='ignore')
    xbmcplugin.setContent(HANDLE, 'genres')

    pattern = re.compile(
        r'href="([^"]*categoria\.php\?cat=[^"]*)"[^>]*class="[^"]*main-category[^"]*"[^>]*>.*?category-title">([^<]+)</div>',
        re.DOTALL
    )

    for link, title in pattern.findall(page_html):
        url = build_url({'mode': 'category', 'url': link})
        li = xbmcgui.ListItem(label=title.strip())
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


# ==============================
# LIST CATEGORY
# ==============================
def list_category(category_url):
    data = get_data(category_url)
    if not data:
        return

    page_html = data.decode('utf-8', errors='ignore')
    mapping = load_mapping()
    xbmcplugin.setContent(HANDLE, 'videos')

    blocks = re.findall(r'<a[^>]+class="channel-card"[^>]*>.*?</a>', page_html, re.DOTALL)

    parsed = []
    station_ids = []

    for block in blocks:
        name_m = re.search(r'class="channel-name">([^<]+)</span>', block)
        link_m = re.search(r'href="([^"]+)"', block)
        img_m = re.search(r'src="([^"]+)"', block)

        if not (name_m and link_m):
            continue

        name = html_lib.unescape(name_m.group(1).strip())
        link = link_m.group(1)

        key = clean_name(name)
        station_id = mapping.get(key)

        img_src = img_m.group(1) if img_m else ""
        parsed.append((name, link, img_src, station_id))

        if station_id:
            station_ids.append(station_id)

    # Prefetch EPG in parallel (blocking, stable)
        # Prefetch EPG in parallel (blocking, stable)
    # IMPORTANT: prefetch doar ce NU este deja in cache (RAM/DISK) sau este expirat,
    # altfel reintrarea in categorie ar face request-uri inutile si ar introduce delay.
    now_ts = time.time()
    station_ids_to_fetch = []
    seen_sid = set()

    for sid in station_ids:
        if not sid:
            continue
        sid = str(sid)
        if sid in seen_sid:
            continue
        seen_sid.add(sid)

        # RAM cache valid?
        ram_entry = _EPG_CACHE.get(sid)
        if ram_entry and float(ram_entry.get("expire", 0)) > now_ts:
            continue

        # Disk cache valid?
        disk_info = _disk_cache_get(sid)
        if disk_info:
            # optional: incalzeste RAM pentru acces instant in acest run
            _EPG_CACHE[sid] = {"expire": now_ts + 30, "data": disk_info}
            continue

        station_ids_to_fetch.append(sid)

    if station_ids_to_fetch:
        prefetch_epg_station_ids(station_ids_to_fetch, max_workers=PREFETCH_WORKERS)

    for (name, link, img_src, station_id) in parsed:
        info = load_epg_by_station_id(station_id) if station_id else None
        plot, tagline = build_epg_plot(info) if info else ("EPG indisponibil", "")

        logo_orig = urllib.parse.urljoin(BASE_URL, img_src) if img_src else ""
        clean_img = logo_orig.replace('https://', '').replace('http://', '')
        poster = f"https://images.weserv.nl/?url={clean_img}&w=320&h=450&fit=contain&bg=transparent"

        url = build_url({'mode': 'play', 'url': link, 'name': name, 'logo': poster})
        li = xbmcgui.ListItem(label=name)
        li.setArt({'thumb': poster, 'icon': poster, 'poster': poster})
        li.setInfo('video', {'title': name, 'plot': plot, 'tagline': tagline})
        li.setProperty('IsPlayable', 'true')

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


# ==============================
# PLAY
# ==============================
def play_video(video_url, name, logo):
    data = get_data(video_url)
    if not data:
        return

    page_html = data.decode('utf-8', errors='ignore')

    streams_match = re.search(r'const streams\s*=\s*\{([^}]+)\}', page_html, re.DOTALL)
    if not streams_match:
        return

    url_matches = re.findall(r'(\w+)\s*:\s*[\'\"]\s*([^\'\"\s,]+)', streams_match.group(1))
    streams = [(lbl.replace('_', ' ').capitalize(), u.strip()) for lbl, u in url_matches]

    selected_url = ""
    xbmc.log(f"[ROTV123] Selected stream URL: {selected_url}", xbmc.LOGINFO)
    if len(streams) > 1:
        labels = [s[0] for s in streams]
        idx = xbmcgui.Dialog().select(f"Alege sursa pentru {name}", labels)
        if idx > -1:
            selected_url = streams[idx][1]
        else:
            return
    elif streams:
        selected_url = streams[0][1]

    if selected_url:
        #header = f'User-Agent={USER_AGENT}&Referer={BASE_URL}/'
        header = (
            f'User-Agent={USER_AGENT}'
            f'&Referer=https://rotv123.com/'
            f'&Origin=https://rotv123.com'
        )

        play_item = xbmcgui.ListItem(label=name)
        if logo:
            play_item.setArt({'thumb': logo, 'icon': logo})
        xbmc.log(f"[ROTV123] Final play path: {selected_url}|{header}", xbmc.LOGINFO)
        play_item.setPath(selected_url + '|' + header)
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)


# ==============================
# ROUTER
# ==============================
def build_url(query):
    return URL + '?' + urllib.parse.urlencode(query)


def router(param_string):
    params = dict(urllib.parse.parse_qsl(param_string))
    mode = params.get('mode')

    if mode == 'category':
        list_category(params.get('url'))
    elif mode == 'play':
        play_video(params.get('url'), params.get('name'), params.get('logo'))
    else:
        main_menu()


if __name__ == '__main__':
    router(sys.argv[2][1:])
