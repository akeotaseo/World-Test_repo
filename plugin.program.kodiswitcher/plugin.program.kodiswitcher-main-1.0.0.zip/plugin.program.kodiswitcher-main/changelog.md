# Changelog

### v1.0.0 (2025-10-08)

- Initial release
- Scan for Kodi directories in /sdcard/
- Switch between builds with confirmation
- Automatically quit Kodi after switching
- Display clear restart instructions to user
- Manual force stop and restart process
