from urllib.parse import urlencode, parse_qsl
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from json import loads
from datetime import datetime
from calendar import timegm
from time import gmtime, sleep
from xbmc import executebuiltin
import re, sys, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/605.1.15 EdgA/132.0.0.0'
timestamp = timegm(gmtime())
def addDir(title, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=20, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        addDir('EVENT', 'live_socolive')
        u = f'https://json.vnres.co/matches.json?v={timestamp}'
        resp = getlink(u, u, 400)
        nd = re.search(r'(\{.*\})', resp.text, re.DOTALL)[1]
        m = loads(nd)
        mh = m['data']['0']
        for k in mh:
            tg = datetime.fromtimestamp(int(k['matchTime'])/1000).strftime('%H:%M %d/%m')
            tenm = f"{tg} {k['hostName']} vs {k['guestName']}"
            addDir(tenm, 'list_socolive', idv = k['scheduleId'], name=tenm)
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'list_socolive':
        u = f"https://json.vnres.co/matches.json?v={timestamp}"
        resp = getlink(u, u, 400)
        nd = re.search(r'(\{.*\})', resp.text, re.DOTALL)[1]
        m = loads(nd)
        mh = m['data']['0']
        for k in mh:
            for l in k['anchors']:
                if k['scheduleId'] == int(params['idv']):
                    tenm = f"{l['nickName']} - {params['name']}"
                    addDir(tenm, 'play', id = l['anchor']['roomNum'], is_folder=False)
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'live_socolive':
        u = f"http://json.vnres.co/all_live_rooms.json?v={timestamp}"
        resp = getlink(u, u, 400)
        nd = re.search(r'(\{.*\})', resp.text, re.DOTALL)[1]
        m = loads(nd)
        mh = m['data']['hot']
        for k in mh:
            tenm = f'{k["title"]} ({k["anchor"]["nickName"]})'
            addDir(tenm, 'play', id = k['roomNum'], is_folder=False)
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'play':
        url = f'https://json.vnres.co/room/{params["id"]}/detail.json?v={timestamp}'
        r = getlink(url, url,-1)
        nd = re.search(r'(\{.*\})', r.text, re.DOTALL)[1]
        play_item = xbmcgui.ListItem(offscreen=True)
        linkplay = loads(nd)['data']['stream']['hdFlv']
        linkplay = re.sub(r'\s+', '%20', linkplay.strip(), flags=re.UNICODE)
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
try:
    router(sys.argv[2][1:])
except:
    pass