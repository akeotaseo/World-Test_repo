# -*- coding: utf-8 -*-
import sys
import json
import requests
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

ADDON      = xbmcaddon.Addon()
ADDON_ID   = ADDON.getAddonInfo("id")
HANDLE     = int(sys.argv[1]) if len(sys.argv) > 1 else -1

# Your full master list
MASTER_URL = "https://uck.st/splite_movies/master_list_1.json"


# -----------------------------------------------------
# Helper: Load master JSON
# -----------------------------------------------------
def _load_json(url):
    xbmc.log(f"[DiamondSearch] Loading: {url}", xbmc.LOGINFO)
    try:
        r = requests.get(url, timeout=12)
        if not r.ok:
            xbmc.log(f"[DiamondSearch] HTTP {r.status_code}", xbmc.LOGERROR)
            return []
        return r.json()
    except Exception as e:
        xbmc.log(f"[DiamondSearch] Error loading: {e}", xbmc.LOGERROR)
        return []


# -----------------------------------------------------
# Helper: Render search results using your V4 system
# -----------------------------------------------------
def _render_results(movies, query, mode):
    from modules.rdmagnet_browser_v4_player import render_movie_list

    if not movies:
        xbmcgui.Dialog().ok(
            "Diamond Search",
            f"No results found for:\n[COLOR gold]{query}[/COLOR]\n({mode})"
        )
        return

    label = f"Search: {query}  ({mode})"
    render_movie_list(movies, label)


# -----------------------------------------------------
# Main Search Handler
# -----------------------------------------------------
def run_text_search():

    # -------------------------------------------------
    # 1) Select search mode
    # -------------------------------------------------
    mode_selector = xbmcgui.Dialog().select(
        "Diamond Search — Choose Search Type",
        [
            "Search by Title",
            "Search by Plot"
        ]
    )

    if mode_selector == -1:
        return

    search_mode = "title" if mode_selector == 0 else "plot"
    search_label = "Title" if search_mode == "title" else "Plot"

    # -------------------------------------------------
    # 2) Ask for search string
    # -------------------------------------------------
    kb = xbmc.Keyboard("", f"Search Movies by {search_label}")
    kb.doModal()
    if not kb.isConfirmed():
        return

    query = kb.getText().strip()
    if not query:
        xbmcgui.Dialog().ok("Diamond Search", "Nothing entered.")
        return

    search_q = query.lower()

    # -------------------------------------------------
    # 3) Load list
    # -------------------------------------------------
    full_list = _load_json(MASTER_URL)
    if not full_list or not isinstance(full_list, list):
        xbmcgui.Dialog().ok("Diamond Search", "Failed to load master list.")
        return

    # -------------------------------------------------
    # 4) Filter based on search mode
    # -------------------------------------------------
    if search_mode == "title":
        results = [mv for mv in full_list if search_q in mv.get("title", "").lower()]
    else:
        results = [mv for mv in full_list if search_q in mv.get("plot", "").lower()]

    # -------------------------------------------------
    # 5) Save results for widget use
    # -------------------------------------------------
    try:
        save_path = xbmcvfs.translatePath(
            f"special://profile/addon_data/{ADDON_ID}/last_search_text.json"
        )
        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        xbmc.log(f"[DiamondSearch] Saved: {save_path}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[DiamondSearch] Save error: {e}", xbmc.LOGERROR)

    # -------------------------------------------------
    # 6) Render
    # -------------------------------------------------
    _render_results(results, query, search_label)
