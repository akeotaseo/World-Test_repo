import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.matrixflix/?site=cFav&function=delBookmarkMenu)", True)
