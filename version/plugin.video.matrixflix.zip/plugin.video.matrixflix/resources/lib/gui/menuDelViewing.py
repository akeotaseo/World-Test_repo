import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.matrixflix/?site=cViewing&function=delViewingMenu)", True)
