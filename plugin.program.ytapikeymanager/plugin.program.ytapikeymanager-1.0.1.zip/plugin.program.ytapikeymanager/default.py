import xbmcgui
import xbmcaddon
import os
import shutil
from xbmcvfs import translatePath
import applier

addon = xbmcaddon.Addon()

def ensure_keys_file_exists():
    userdata_path = translatePath("special://profile/addon_data/plugin.program.ytapikeymanager")
    os.makedirs(userdata_path, exist_ok=True)
    default_keys_path = os.path.join(os.path.dirname(__file__), "keys.json")
    target_keys_path = os.path.join(userdata_path, "keys.json")
    if not os.path.exists(target_keys_path) and os.path.exists(default_keys_path):
        shutil.copy2(default_keys_path, target_keys_path)

def main_menu():
    ensure_keys_file_exists()
    dialog = xbmcgui.Dialog()

    show_create_default = addon.getSettingBool("show_create_default")
    show_apply_default = addon.getSettingBool("show_apply_default")

    options = []

    if show_create_default:
        options.append("Create API/Cred Default")
    if show_apply_default:
        options.append("Apply API/Cred Default")

    options.extend([
        "Backup → API Keys Only",
        "Backup → Access Credentials Only",
        "Backup → Full YouTube Settings",
        "Restore → API Keys",
        "Restore → Access Credentials",
        "Restore → Full YouTube Backup",
        "Export All Backups",
        "Import All Backups",
        "Exit"
    ])

    if not options:
        dialog.ok("YT API Key Manager", "No menu options are enabled in settings.")
        return

    while True:
        choice = dialog.select("YT API Key Manager", options)
        if choice == -1 or options[choice] == "Exit":
            break

        if options[choice] == "Create API/Cred Default":
            applier.create_api_default()
        elif options[choice] == "Apply API/Cred Default":
            applier.apply_api_default()
        elif options[choice] == "Backup → API Keys Only":
            applier.backup_youtube_settings(only="api")
        elif options[choice] == "Backup → Access Credentials Only":
            applier.backup_youtube_settings(only="access")
        elif options[choice] == "Backup → Full YouTube Settings":
            applier.backup_youtube_settings(only="both")
        elif options[choice] == "Restore → API Keys":
            applier.restore_youtube_settings(only="api")
        elif options[choice] == "Restore → Access Credentials":
            applier.restore_youtube_settings(only="access")
        elif options[choice] == "Restore → Full YouTube Backup":
            applier.restore_youtube_settings(only="both")
        elif options[choice] == "Export All Backups":
            applier.export_backups()
        elif options[choice] == "Import All Backups":
            applier.import_backups()

if __name__ == "__main__":
    main_menu()
