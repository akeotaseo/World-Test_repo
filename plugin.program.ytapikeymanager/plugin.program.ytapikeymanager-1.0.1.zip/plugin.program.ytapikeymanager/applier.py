import os
import shutil
import xbmcgui
from xbmcvfs import translatePath, mkdir, exists
from datetime import datetime

YOUTUBE_SETTINGS = translatePath("special://profile/addon_data/plugin.video.youtube/settings.xml")
ACCESS_MANAGER = translatePath("special://profile/addon_data/plugin.video.youtube/access_manager.json")
BACKUP_DIR = translatePath("special://profile/addon_data/plugin.program.ytapikeymanager/backups/")
DEFAULTS_DIR = translatePath("special://home/addons/plugin.program.ytapikeymanager/defaults/")

def ensure_backup_dir():
    if not exists(BACKUP_DIR):
        mkdir(BACKUP_DIR)

def ensure_defaults_dir():
    if not exists(DEFAULTS_DIR):
        mkdir(DEFAULTS_DIR)

# ===== DEFAULT CREATION =====
def create_api_default():
    ensure_defaults_dir()
    dialog = xbmcgui.Dialog()
    slot = dialog.select("Select Default Slot (1–6)", [f"Slot {i}" for i in range(1, 7)])
    if slot == -1:
        return
    slot += 1  # make it human-readable 1-6

    if not os.path.exists(YOUTUBE_SETTINGS):
        dialog.ok("YT API Key Manager", "No YouTube API key found to save.")
        return

    dest_api = os.path.join(DEFAULTS_DIR, f"default_api_{slot}.xml")
    shutil.copy2(YOUTUBE_SETTINGS, dest_api)

    if os.path.exists(ACCESS_MANAGER):
        dest_creds = os.path.join(DEFAULTS_DIR, f"default_creds_{slot}.json")
        shutil.copy2(ACCESS_MANAGER, dest_creds)
        dialog.ok("YT API Key Manager", f"Default API Key & Credentials saved to slot {slot}.")
    else:
        dialog.ok("YT API Key Manager", f"Default API Key saved to slot {slot} (no credentials found).")

# ===== DEFAULT APPLICATION =====
def apply_api_default():
    ensure_defaults_dir()
    dialog = xbmcgui.Dialog()
    slot = dialog.select("Select Default Slot (1–6)", [f"Slot {i}" for i in range(1, 7)])
    if slot == -1:
        return
    slot += 1

    api_file = os.path.join(DEFAULTS_DIR, f"default_api_{slot}.xml")
    creds_file = os.path.join(DEFAULTS_DIR, f"default_creds_{slot}.json")

    if not os.path.exists(api_file) and not os.path.exists(creds_file):
        dialog.ok("YT API Key Manager", f"Slot {slot} is empty. Create a default first.")
        return

    # Warning before overwriting
    confirm = dialog.yesno(
        "Overwrite Confirmation",
        f"Applying default from slot {slot} will overwrite your current API key and/or credentials.\nContinue?"
    )
    if not confirm:
        return

    if os.path.exists(api_file):
        shutil.copy2(api_file, YOUTUBE_SETTINGS)
    if os.path.exists(creds_file):
        shutil.copy2(creds_file, ACCESS_MANAGER)

    dialog.ok("YT API Key Manager", f"Default from slot {slot} applied successfully.")

# ===== EXISTING FUNCTIONS FROM YOUR ADD-ON =====
def backup_youtube_settings(only="both"):
    ensure_backup_dir()
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    backed_up = []

    if only in ("api", "both") and os.path.exists(YOUTUBE_SETTINGS):
        dst = os.path.join(BACKUP_DIR, f"settings.xml.bak_{timestamp}")
        shutil.copy2(YOUTUBE_SETTINGS, dst)
        backed_up.append("API Keys")

    if only in ("access", "both") and os.path.exists(ACCESS_MANAGER):
        dst = os.path.join(BACKUP_DIR, f"access_manager.json.bak_{timestamp}")
        shutil.copy2(ACCESS_MANAGER, dst)
        backed_up.append("Access Credentials")

    if backed_up:
        xbmcgui.Dialog().ok("YT API Key Manager", "Backup complete:\n" + ", ".join(backed_up))
    else:
        xbmcgui.Dialog().ok("YT API Key Manager", "Nothing was backed up.")

def restore_youtube_settings(only="both"):
    ensure_backup_dir()
    files = []
    if only in ("api", "both"):
        files += [(f, "api") for f in os.listdir(BACKUP_DIR) if f.startswith("settings.xml.bak_")]
    if only in ("access", "both"):
        files += [(f, "access") for f in os.listdir(BACKUP_DIR) if f.startswith("access_manager.json.bak_")]

    if not files:
        xbmcgui.Dialog().ok("YT API Key Manager", "No backups found.")
        return

    display = [f"{label.upper()} → {name}" for name, label in files]
    idx = xbmcgui.Dialog().select("Select backup to restore", display)

    if idx >= 0:
        name, label = files[idx]
        src = os.path.join(BACKUP_DIR, name)
        dst = YOUTUBE_SETTINGS if label == "api" else ACCESS_MANAGER
        shutil.copy2(src, dst)
        xbmcgui.Dialog().ok("YT API Key Manager", f"Restored {label.upper()}:\n{name}")

def export_backups():
    ensure_backup_dir()
    dialog = xbmcgui.Dialog()
    target = dialog.browse(3, "Select Export Destination", "files")
    if not target:
        return

    files = os.listdir(BACKUP_DIR)
    if not files:
        dialog.ok("YT API Key Manager", "No backup files to export.")
        return

    count = 0
    for f in files:
        src = os.path.join(BACKUP_DIR, f)
        dst = os.path.join(target, f)
        try:
            shutil.copy2(src, dst)
            count += 1
        except:
            pass

    dialog.ok("YT API Key Manager", f"Exported {count} backup(s) to:\n{target}")

def import_backups():
    dialog = xbmcgui.Dialog()
    folder = dialog.browse(0, "Select Folder to Import From", "files")
    if not folder:
        dialog.ok("Import Cancelled", "No folder selected.")
        return

    folder = translatePath(folder)
    imported_files = 0
    for filename in os.listdir(folder):
        src = os.path.join(folder, filename)
        dest = os.path.join(BACKUP_DIR, filename)
        if os.path.isfile(src):
            try:
                shutil.copy2(src, dest)
                imported_files += 1
            except:
                pass

    if imported_files > 0:
        dialog.ok("Import Complete", f"{imported_files} file(s) imported.")
    else:
        dialog.ok("Import Failed", "No valid files found.")
