# modules/path_helper.py
# Central path and storage helper functions for Kodi’s Little Helper.
# Supports SAF on Android, prevents saving to Kodi root (except Imported_Files).

import os
import xbmc
import xbmcgui
import xbmcvfs


# ---------- Basic Paths ----------
def kodi_root():
    """Return Kodi's root path (translated)."""
    return xbmcvfs.translatePath("special://home/")

def userdata_path():
    """Return Kodi's userdata path."""
    return xbmcvfs.translatePath("special://userdata/")

def imported_files_path():
    """Return path to Imported_Files directory, create if missing."""
    path = os.path.join(kodi_root(), "Imported_Files")
    if not os.path.exists(path):
        os.makedirs(path, exist_ok=True)
    return path


# ---------- Platform Detection ----------
def is_android():
    """Check if Kodi is running on Android."""
    try:
        return xbmc.getCondVisibility("system.platform.android")
    except Exception:
        return False


# ---------- SAF + FS Helpers ----------
def pick_safe_folder(title="Choose a folder"):
    """
    Pick a folder safely:
    - On Android, use SAF (Storage Access Framework).
    - Elsewhere, use Kodi's file browser.
    """
    if is_android():
        # SAF picker on Android
        saf_uri = xbmcgui.Dialog().browse(3, title, "files", "", True, False)
        return saf_uri if saf_uri else None
    else:
        # Standard filesystem picker
        path = xbmcgui.Dialog().browse(3, title, "files", "", True, False)
        return path if path else None


def join_saf(folder_uri, filename):
    """
    Join SAF folder URI with filename (dummy join since SAF URIs are virtual).
    """
    if not folder_uri.endswith("/"):
        folder_uri += "/"
    return folder_uri + filename


# ---------- File & Path Utilities ----------
def default_filename(base, ext=".zip"):
    """Generate a timestamped filename like KodiRootBackup-YYYY-MM-DD-HHMMSS.zip."""
    import time
    ts = time.strftime("%Y-%m-%d-%H%M%S")
    return f"{base}-{ts}{ext}"


def is_safe_destination(dest_path):
    """
    Check if a destination path is safe:
    - Not Kodi root
    - Imported_Files is allowed
    """
    root = kodi_root()
    if dest_path.startswith(root):
        if dest_path.rstrip("/").endswith("Imported_Files"):
            return True
        return False
    return True
