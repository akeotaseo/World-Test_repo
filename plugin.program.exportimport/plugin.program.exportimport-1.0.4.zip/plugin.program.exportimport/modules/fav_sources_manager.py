# modules/fav_sources_manager.py

import os
import shutil
import xbmc
import xbmcgui
import xbmcvfs
from datetime import datetime

# Kodi profile paths
FAV_PATH   = xbmcvfs.translatePath("special://profile/favourites.xml")
SRC_PATH   = xbmcvfs.translatePath("special://profile/sources.xml")

# Export base
IMPORT_DIR = xbmcvfs.translatePath("special://home/Imported_Files")

# Subdirectories for neatness
FAV_DIR = os.path.join(IMPORT_DIR, "Favorites")
SRC_DIR = os.path.join(IMPORT_DIR, "Sources")

# Ensure folders exist
for d in [IMPORT_DIR, FAV_DIR, SRC_DIR]:
    if not xbmcvfs.exists(d):
        xbmcvfs.mkdirs(d)


def timestamped_filename(base: str) -> str:
    """Return filename with timestamp suffix."""
    now = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    name, ext = os.path.splitext(base)
    return f"{name}_{now}{ext}"


def export_favorites():
    """Export favourites.xml to Imported_Files/Favorites/ with timestamp"""
    try:
        if xbmcvfs.exists(FAV_PATH):
            dest = os.path.join(FAV_DIR, timestamped_filename("favourites.xml"))
            shutil.copy(FAV_PATH, dest)
            xbmcgui.Dialog().ok("Export Favorites", f"Exported to:\n{dest}")
        else:
            xbmcgui.Dialog().ok("Export Favorites", "No favourites.xml found to export.")
    except Exception as e:
        xbmc.log(f"[Export Favorites] Error: {e}", xbmc.LOGERROR)


def import_favorites():
    """Import favourites.xml with picker for timestamped backups"""
    try:
        files = sorted(
            [f for f in os.listdir(FAV_DIR) if f.startswith("favourites_") and f.endswith(".xml")],
            reverse=True
        )
        if not files:
            xbmcgui.Dialog().ok("Import Favorites", "No exported favourites.xml found.")
            return

        # Let user pick which file
        choice = xbmcgui.Dialog().select("Select Favorites Backup", files)
        if choice == -1:
            return  # cancelled

        src = os.path.join(FAV_DIR, files[choice])
        shutil.copy(src, FAV_PATH)
        xbmcgui.Dialog().ok("Import Favorites", f"Imported:\n{files[choice]}\nRestart Kodi to apply.")
    except Exception as e:
        xbmc.log(f"[Import Favorites] Error: {e}", xbmc.LOGERROR)

def export_sources():
    """Export sources.xml to Imported_Files/Sources/ with timestamp"""
    try:
        if xbmcvfs.exists(SRC_PATH):
            dest = os.path.join(SRC_DIR, timestamped_filename("sources.xml"))
            shutil.copy(SRC_PATH, dest)
            xbmcgui.Dialog().ok("Export Sources", f"Exported to:\n{dest}")
        else:
            xbmcgui.Dialog().ok("Export Sources", "No sources.xml found to export.")
    except Exception as e:
        xbmc.log(f"[Export Sources] Error: {e}", xbmc.LOGERROR)


def import_sources():
    """Import sources.xml with picker for timestamped backups"""
    try:
        files = sorted(
            [f for f in os.listdir(SRC_DIR) if f.startswith("sources_") and f.endswith(".xml")],
            reverse=True
        )
        if not files:
            xbmcgui.Dialog().ok("Import Sources", "No exported sources.xml found.")
            return

        # Let user pick which file
        choice = xbmcgui.Dialog().select("Select Sources Backup", files)
        if choice == -1:
            return  # cancelled

        src = os.path.join(SRC_DIR, files[choice])
        shutil.copy(src, SRC_PATH)
        xbmcgui.Dialog().ok("Import Sources", f"Imported:\n{files[choice]}\nRestart Kodi to apply.")
    except Exception as e:
        xbmc.log(f"[Import Sources] Error: {e}", xbmc.LOGERROR)