# modules/apk_installer.py
# Pick an APK from filesystem or SAF, copy it to a safe location, and launch Android's installer.

import os
import shutil
import xbmc
import xbmcgui
import xbmcvfs
from modules import apk_saf_picker


def get_public_download_folder():
    """Return a safe, writable folder for APKs."""
    possible_paths = [
        "/storage/emulated/0/Download",  # Most common
        "/sdcard/Download",
        "/storage/self/primary/Download"
    ]
    for path in possible_paths:
        if os.path.exists(path) and os.access(path, os.W_OK):
            return path
    # Fallback: Kodi home folder
    return xbmcvfs.translatePath("special://home/Imported_Files")


def install_apk():
    dialog = xbmcgui.Dialog()

    # Step 1: Pick APK
    apk_path = apk_saf_picker.pick_file("Select APK to install", file_filter=".apk")
    if not apk_path:
        return

    # Step 2: Ensure file ends in .apk
    apk_name = os.path.basename(apk_path)
    if not apk_name.lower().endswith(".apk"):
        apk_name += ".apk"

    # Step 3: Copy APK to a safe location
    dest_folder = get_public_download_folder()
    dest_path = os.path.join(dest_folder, apk_name)

    try:
        # Copy file to installer-friendly location
        xbmcvfs.copy(apk_path, dest_path)
        xbmc.log(f"[APK Installer] Copied APK to: {dest_path}", xbmc.LOGINFO)
    except Exception as e:
        dialog.ok("APK Installer", f"Failed to copy APK:\n{e}")
        return

    # Step 4: Launch Android's installer
    try:
        xbmc.executebuiltin(
            f'StartAndroidActivity("", "android.intent.action.VIEW", "application/vnd.android.package-archive", "file://{dest_path}")'
        )
        dialog.notification("APK Installer", "Launching Android installer...", xbmcgui.NOTIFICATION_INFO)
    except Exception as e:
        dialog.ok("APK Installer", f"Failed to launch installer:\n{e}")
