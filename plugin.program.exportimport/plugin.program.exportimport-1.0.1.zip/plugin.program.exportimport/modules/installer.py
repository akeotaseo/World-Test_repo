# modules/installer.py
# Handles Add-on and Build/Updater installation from URL or file system.

import os
import re
import json
import zipfile
import shutil
import urllib.request
import datetime

import xbmc
import xbmcgui
import xbmcvfs

CHUNK_SIZE = 1024 * 128  # 128 KB


# ------------------------------
# Helpers / UI
# ------------------------------

def _notify(title, msg, ms=3000):
    xbmcgui.Dialog().notification(title, msg, xbmcgui.NOTIFICATION_INFO, ms)

def _dialog_yesno(title, msg):
    try:
        return xbmcgui.Dialog().yesno(title, msg)
    except Exception:
        return True

def _load_json_list(local_file: str = None, remote_url: str = None):
    try:
        if local_file and xbmcvfs.exists(local_file):
            real = xbmcvfs.translatePath(local_file)
            with open(real, "r", encoding="utf-8") as f:
                return json.load(f)
        elif remote_url:
            req = urllib.request.Request(remote_url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        xbmcgui.Dialog().ok("List Error", f"Could not load list:\n{e}")
    return []

def _now_stamp():
    return datetime.datetime.now().strftime("%Y%m%d-%H%M%S")


# ------------------------------
# Backup helpers
# ------------------------------

def _backup_file(target_real_path):
    try:
        if not os.path.exists(target_real_path):
            return
        home_real = xbmcvfs.translatePath("special://home/")
        rel = os.path.relpath(target_real_path, home_real)
        backup_root = os.path.join(home_real, "backup_updater", "file_overwrites")
        backup_real_path = os.path.join(backup_root, rel)
        os.makedirs(os.path.dirname(backup_real_path), exist_ok=True)
        shutil.copy2(target_real_path, backup_real_path)
    except Exception as e:
        xbmc.log(f"[Installer] Backup file failed {target_real_path}: {e}", xbmc.LOGWARNING)

def _backup_folder(folder_real_path, category, subname):
    try:
        if not os.path.exists(folder_real_path):
            return
        home_real = xbmcvfs.translatePath("special://home/")
        backup_root = os.path.join(home_real, "backup_updater", "folders", category, subname, _now_stamp())
        if os.path.exists(backup_root):
            shutil.rmtree(backup_root, ignore_errors=True)
        shutil.copytree(folder_real_path, backup_root)
    except Exception as e:
        xbmc.log(f"[Installer] Backup folder failed {folder_real_path}: {e}", xbmc.LOGWARNING)


# ------------------------------
# Download
# ------------------------------

def _download_zip(url, dest_vfs_folder="special://home/addons/packages/"):
    try:
        if not xbmcvfs.exists(dest_vfs_folder):
            xbmcvfs.mkdirs(dest_vfs_folder)

        from urllib.parse import urlsplit, unquote
        fname = unquote(os.path.basename(urlsplit(url).path)) or "download.zip"

        dest_real_folder = xbmcvfs.translatePath(dest_vfs_folder)
        dest_real_path = os.path.join(dest_real_folder, fname)

        dp = xbmcgui.DialogProgress()
        dp.create("Downloading", fname)

        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=60) as resp:
            total = resp.getheader("Content-Length")
            total = int(total) if total else 0
            read = 0
            with open(dest_real_path, "wb") as out_f:
                while True:
                    chunk = resp.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    out_f.write(chunk)
                    read += len(chunk)
                    if total:
                        dp.update(int((read / total) * 100), f"{read}/{total} bytes")
        dp.close()
        return dest_real_path
    except Exception as e:
        try:
            dp.close()
        except Exception:
            pass
        xbmcgui.Dialog().ok("Download Failed", str(e))
        return None


# ------------------------------
# ZIP safety
# ------------------------------

def _is_dir_member(name: str) -> bool:
    return name.endswith("/")

def _skip_member(name: str) -> bool:
    parts = name.split("/")
    return parts[0] in {"__MACOSX", ".DS_Store"} or name.endswith(".DS_Store")

def _safe_target_path(dest_base_real: str, member: str) -> str:
    normalized = os.path.normpath(os.path.join(dest_base_real, member))
    if not normalized.startswith(os.path.normpath(dest_base_real)):
        raise ValueError(f"Blocked path traversal for member: {member}")
    return normalized


# ------------------------------
# Write helper
# ------------------------------

def _write_file(target, data):
    """Safe file write helper, always inside Kodi's home."""
    try:
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, "wb") as f:
            f.write(data)
        return True
    except Exception as e:
        xbmc.log(f"[Installer] Failed to write {target}: {e}", xbmc.LOGERROR)
        return False


# ------------------------------
# Detection
# ------------------------------

def detect_package_type(zip_real_path):
    try:
        with zipfile.ZipFile(zip_real_path, 'r') as zf:
            names = [n for n in zf.namelist() if not _skip_member(n)]
            top = {n.split('/')[0] for n in names if '/' in n}
            if 'addons' in top or 'userdata' in top:
                return 'build'
            if any(n.endswith('addon.xml') for n in names):
                return 'addon'
            return 'unknown'
    except Exception:
        return 'unknown'

def _find_addon_xml(zf: zipfile.ZipFile):
    for n in zf.namelist():
        if n.endswith('addon.xml') and not _skip_member(n):
            return n
    return None

def _read_addon_id_from_xml_bytes(xml_bytes: bytes):
    try:
        text = xml_bytes.decode('utf-8', errors='ignore')
        m = re.search(r'<addon[^>]*\bid\s*=\s*"([^"]+)"', text, flags=re.I)
        if m:
            return m.group(1).strip()
    except Exception:
        pass
    return None


# ------------------------------
# Extraction
# ------------------------------

def _extract_build_zip(zip_real_path: str, dest_home_real: str) -> bool:
    """Extract a build/updater zip into special://home/ with backups and safety."""
    dp = None
    try:
        addons_real = os.path.join(dest_home_real, "addons")
        userdata_real = os.path.join(dest_home_real, "userdata")
        if os.path.exists(addons_real):
            _backup_folder(addons_real, "builds", "addons")
        if os.path.exists(userdata_real):
            _backup_folder(userdata_real, "builds", "userdata")

        with zipfile.ZipFile(zip_real_path, 'r') as zf:
            names = [n for n in zf.namelist() if not _skip_member(n)]
            files = [n for n in names if not _is_dir_member(n)]

            dp = xbmcgui.DialogProgress()
            dp.create("Installing Build/Updater", os.path.basename(zip_real_path))

            for i, n in enumerate(files, 1):
                target = _safe_target_path(dest_home_real, n)
                _backup_file(target)
                data = zf.read(n)
                _write_file(target, data)
                dp.update(int(i * 100 / max(len(files), 1)), n)

        dp.close()
        return True

    except Exception as e:
        try:
            dp.close()
        except Exception:
            pass
        xbmcgui.Dialog().ok("Error", f"Failed to extract build/updater zip:\n{e}")
        return False


# ------------------------------
# Public: Build/Updater
# ------------------------------

def install_build_from_filesystem():
    zip_vfs = xbmcgui.Dialog().browse(1, "Select Build/Updater ZIP", "files", ".zip", False, False, "")
    if not zip_vfs:
        return
    zip_real = xbmcvfs.translatePath(zip_vfs)

    pkg = detect_package_type(zip_real)
    if pkg != 'build':
        xbmcgui.Dialog().ok("Not a Build", "This ZIP does not look like a valid Build/Updater package.")
        return

    if not _dialog_yesno("Updater Installer", "This will apply updates into Kodi home and backup overwritten files. Continue?"):
        return

    home_real = xbmcvfs.translatePath("special://home/")
    if _extract_build_zip(zip_real, home_real):
        _notify("Updater Installer", f"Installed build/update from: {os.path.basename(zip_real)}")
