# modules/build_backup.py
# Handles creating full Kodi root backups while excluding binary add-ons.
# Now SAF-aware on Android (Android 11–15+).

import os
import time
import zipfile

import xbmc
import xbmcgui
import xbmcvfs

from modules import binary_scanner
from modules import saf_picker   # SAF helpers

# ---------- tiny helpers ----------

def _kodi_root():
    return xbmcvfs.translatePath("special://home/")

def _userdata():
    return xbmcvfs.translatePath("special://userdata/")

def _is_android():
    try:
        return xbmc.getCondVisibility("system.platform.android")
    except Exception:
        return False

# ---------- Dialog helpers ----------

def _show_wait(msg):
    """Show a simple 'Please wait...' dialog using DialogProgress."""
    pd = xbmcgui.DialogProgress()
    pd.create("Kodi’s Little Helper")
    pd.update(0, msg)
    return pd

def _close_wait(waitdlg):
    """Close the wait/progress dialog."""
    try:
        waitdlg.close()
    except Exception:
        pass

# ---------- Create Kodi Root Backup ----------

def create_root_backup():
    dialog = xbmcgui.Dialog()
    root_path = _kodi_root()

    # Step 0: propose default name
    default_name = f"KodiRootBackup-{time.strftime('%Y-%m-%d-%H%M%S')}.zip"

    # Step 1: Run binary scan
    waitdlg = _show_wait("Please wait… scanning add-ons")
    try:
        safe_addons, binary_addons = binary_scanner.scan_addons()
    finally:
        _close_wait(waitdlg)

    if binary_addons:
        xbmc.log(f"[BuildBackup] Excluding binary add-ons: {binary_addons}", xbmc.LOGINFO)
        dialog.ok("Kodi’s Little Helper",
                  "Binary add-ons will be excluded from this backup.")
    else:
        xbmc.log("[BuildBackup] No binary add-ons detected", xbmc.LOGINFO)

    # Step 2: Choose destination (SAF on Android, FS elsewhere)
    dest_folder = saf_picker.pick_folder("Choose backup destination folder")
    if not dest_folder:
        return

    kodi_root = _kodi_root()
    translated_dest_folder = xbmcvfs.translatePath(dest_folder) if not dest_folder.startswith("saf://") else dest_folder

    if isinstance(translated_dest_folder, str) and translated_dest_folder.startswith(kodi_root):
        dialog.ok("Kodi’s Little Helper", "Backup cannot be saved in Kodi’s root directory.")
        return

    name_input = dialog.input("Backup file name (leave blank for default)",
                              type=xbmcgui.INPUT_ALPHANUM, defaultt=default_name)
    if name_input:
        name_input = name_input.strip()
        if not name_input.lower().endswith(".zip"):
            name_input += ".zip"
        zip_dest = saf_picker.join(dest_folder, name_input)
    else:
        zip_dest = saf_picker.join(dest_folder, default_name)

    # Step 3: Collect folders
    include_folders = ["userdata", "addons"]
    if os.path.exists(os.path.join(kodi_root, "media")):
        include_folders.append("media")

    binaries_txt = os.path.join(_userdata(), "build_binaries.txt")
    created_binaries_txt = False
    try:
        if binary_addons:
            with open(binaries_txt, "w", encoding="utf-8") as f:
                f.write(",".join(sorted(binary_addons)))
            created_binaries_txt = True
    except Exception as e:
        xbmc.log(f"[BuildBackup] Could not write build_binaries.txt: {e}", xbmc.LOGWARNING)

    waitdlg = _show_wait("Please wait… preparing file list")
    try:
        file_list = []
        if created_binaries_txt:
            rel_binaries = os.path.relpath(binaries_txt, kodi_root)
            file_list.append((binaries_txt, rel_binaries))

        for folder in include_folders:
            folder_path = os.path.join(kodi_root, folder)
            if not os.path.exists(folder_path):
                continue
            for r, dirs, files in os.walk(folder_path):
                dirs[:] = [d for d in dirs if d != "__pycache__"]
                for f in files:
                    abs_path = os.path.join(r, f)
                    rel_path = os.path.relpath(abs_path, kodi_root)

                    if rel_path.startswith("addons" + os.sep):
                        parts = rel_path.split(os.sep)
                        if len(parts) > 1:
                            addon_id = parts[1]
                            if addon_id in binary_addons:
                                continue

                    file_list.append((abs_path, rel_path))
    finally:
        _close_wait(waitdlg)

    # Step 5: Create ZIP with progress
    dp = xbmcgui.DialogProgress()
    dp.create("Kodi’s Little Helper", "Creating Kodi backup…")
    try:
        zip_real_target = xbmcvfs.translatePath(zip_dest) if not zip_dest.startswith("saf://") else zip_dest

        with zipfile.ZipFile(zip_real_target, "w", zipfile.ZIP_DEFLATED) as zipf:
            total = max(1, len(file_list))
            for idx, (abs_path, rel_path) in enumerate(file_list):
                try:
                    zipf.write(abs_path, rel_path)
                except Exception as e:
                    xbmc.log(f"[BuildBackup] Failed to add {abs_path}: {e}", xbmc.LOGWARNING)

                percent = int((idx + 1) * 100 / total)
                if not dp.iscanceled():
                    dp.update(percent, f"Creating Kodi backup…\n{rel_path}")
                else:
                    dp.close()
                    try:
                        if not zip_dest.startswith("saf://") and os.path.exists(zip_real_target):
                            os.remove(zip_real_target)
                    except Exception:
                        pass
                    dialog.ok("Kodi’s Little Helper", "Backup canceled.")
                    return

        dp.close()
        dialog.ok("Kodi’s Little Helper", f"Backup created:\n[COLOR green]{zip_dest}[/COLOR]")
        xbmc.log(f"[BuildBackup] Backup created at {zip_dest}", xbmc.LOGINFO)

    except Exception as e:
        try:
            dp.close()
        except Exception:
            pass
        xbmc.log(f"[BuildBackup] Failed to create backup: {e}", xbmc.LOGERROR)
        dialog.ok("Kodi’s Little Helper", f"[COLOR red]Backup failed[/COLOR]: {e}")

    finally:
        if created_binaries_txt:
            try:
                if os.path.exists(binaries_txt):
                    os.remove(binaries_txt)
            except Exception as e:
                xbmc.log(f"[BuildBackup] Cleanup failed for build_binaries.txt: {e}", xbmc.LOGWARNING)
