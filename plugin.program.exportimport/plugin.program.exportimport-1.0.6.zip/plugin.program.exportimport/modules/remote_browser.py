# modules/remote_browser.py
# modules/remote_browser.py
# Browse & download remote files (HTTP/FTP) with favorites support

# modules/remote_browser.py
# Browse & download remote files (HTTP/FTP) with favorites support

import os
import json
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import urllib.request
from urllib.parse import urljoin
from html.parser import HTMLParser

ADDON_ID = "plugin.program.exportimport"
ADDON_DATA = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")
FAV_FILE = os.path.join(ADDON_DATA, "remote_favorites.json")
IMPORT_PATH = xbmcvfs.translatePath("special://home/Imported_Files/")

# ---------- Helpers ----------

def ensure_imported_files():
    """Make sure special://home/Imported_Files exists."""
    if not xbmcvfs.exists(IMPORT_PATH):
        xbmcvfs.mkdirs(IMPORT_PATH)

def load_favorites():
    if not os.path.exists(FAV_FILE):
        return []
    try:
        with open(FAV_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def save_favorites(favs):
    os.makedirs(ADDON_DATA, exist_ok=True)
    with open(FAV_FILE, "w", encoding="utf-8") as f:
        json.dump(favs, f, indent=2)

# HTML parser for simple directory listings
class LinkParser(HTMLParser):
    def __init__(self, base_url):
        super().__init__()
        self.links = []
        self.base = base_url
    def handle_starttag(self, tag, attrs):
        if tag == "a":
            href = dict(attrs).get("href")
            if href and not href.startswith("?"):
                self.links.append(urljoin(self.base, href))

def list_remote(url):
    """Return list of files/dirs from URL (basic HTML/FTP index)."""
    try:
        with urllib.request.urlopen(url) as resp:
            content_type = resp.headers.get("Content-Type", "")
            data = resp.read().decode("utf-8", errors="ignore")
            if "html" in content_type:
                parser = LinkParser(url)
                parser.feed(data)
                return parser.links
            else:
                # Direct file, just return itself
                return [url]
    except Exception as e:
        xbmcgui.Dialog().ok("Remote Browser", f"Failed to fetch:\n{url}\nError: {e}")
        return []

def download_files(urls):
    """Download multiple files with progress dialog."""
    ensure_imported_files()
    progress = xbmcgui.DialogProgress()
    total = len(urls)
    success, fail = [], []
    for i, url in enumerate(urls, start=1):
        filename = os.path.basename(url.rstrip("/"))
        dest = os.path.join(IMPORT_PATH, filename)
        try:
            progress.update(int(i * 100 / total),
                            f"Downloading {i} of {total}",
                            filename)
            urllib.request.urlretrieve(url, dest)
            success.append(filename)
        except Exception:
            fail.append(filename)
        if progress.iscanceled():
            break
    progress.close()
    msg = []
    if success: msg.append(f"Downloaded: {', '.join(success)}")
    if fail: msg.append(f"Failed: {', '.join(fail)}")
    xbmcgui.Dialog().ok("Remote Browser", "\n".join(msg) or "No files downloaded")

# ---------- Menu ----------

def remote_browser_menu():
    options = [
        "Enter Remote URL",
        "Browse Favorites",
        "Add Favorite",
        "Remove Favorite",
        "Exit"
    ]
    while True:
        sel = xbmcgui.Dialog().select("Remote Browser", options)
        if sel in (-1, 4):  # Exit
            break
        elif sel == 0:  # Enter URL
            url = xbmcgui.Dialog().input("Enter HTTP/FTP URL")
            if url:
                _browse_url(url)
        elif sel == 1:  # Favorites
            favs = load_favorites()
            if not favs:
                xbmcgui.Dialog().ok("Remote Browser", "No favorites saved.")
                continue
            choice = xbmcgui.Dialog().select("Select Favorite", favs)
            if choice >= 0:
                _browse_url(favs[choice])
        elif sel == 2:  # Add Favorite
            url = xbmcgui.Dialog().input("Enter URL to Save")
            if url:
                favs = load_favorites()
                if url not in favs:
                    favs.append(url)
                    save_favorites(favs)
                    xbmcgui.Dialog().notification("Remote Browser", "Favorite Added")
        elif sel == 3:  # Remove Favorite
            favs = load_favorites()
            if not favs:
                xbmcgui.Dialog().ok("Remote Browser", "No favorites to remove.")
                continue
            choice = xbmcgui.Dialog().select("Remove Which?", favs)
            if choice >= 0:
                favs.pop(choice)
                save_favorites(favs)
                xbmcgui.Dialog().notification("Remote Browser", "Favorite Removed")

def _browse_url(url):
    links = list_remote(url)
    if not links:
        return
    files = [os.path.basename(x.rstrip("/")) or x for x in links]
    sel = xbmcgui.Dialog().multiselect("Select Files to Download", files)
    if sel:
        chosen = [links[i] for i in sel]
        download_files(chosen)
