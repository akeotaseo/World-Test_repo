# source_home.py — Manage Kodi sources.xml entries for this add-on

import os
import shutil
import xbmcvfs
import xbmc
import xml.etree.ElementTree as ET


# ---------- XML Helper ----------

def indent(elem, level=0):
    """Pretty-print indentation for ElementTree output."""
    i = "\n" + level * "    "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "    "
        for child in elem:
            indent(child, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


# ---------- Core Logic ----------

def ensure_kodi_root_source():
    """
    Ensures these sources exist in sources.xml:
      • .Kodi Root Directory → special://home/
      • .Imported_Files → special://home/Imported_Files
      • (Android only) .Device File Storage → /storage/emulated/0/

    Also creates Imported_Files folder on disk.

    Returns True if sources.xml was created or modified (restart required), False otherwise.
    """
    sources_path = xbmcvfs.translatePath('special://profile/sources.xml')
    addon_sources_path = xbmcvfs.translatePath(
        'special://home/addons/plugin.program.exportimport/resources/sources.xml'
    )

    changed = False
    created = False

    # Create sources.xml if missing
    if not xbmcvfs.exists(sources_path):
        parent = os.path.dirname(sources_path)
        if parent and not xbmcvfs.exists(parent):
            xbmcvfs.mkdirs(parent)
        try:
            if not xbmcvfs.copy(addon_sources_path, sources_path):
                raise Exception("xbmcvfs.copy returned False")
        except Exception:
            shutil.copy(addon_sources_path, sources_path)
        xbmc.log("[SourceHome] sources.xml created from resources.", xbmc.LOGINFO)
        created = True

    # Load XML
    tree = ET.parse(sources_path)
    root = tree.getroot()

    # Ensure <files> section exists
    files_section = root.find("files")
    if files_section is None:
        files_section = ET.SubElement(root, "files")
        ET.SubElement(files_section, "default", {"pathversion": "1"})
        changed = True

    def ensure_source(name, path_text):
        """Ensure <source> with given name+path exists in <files>."""
        nonlocal changed
        exists = any(
            (src.find("name") is not None and (src.find("name").text or "").strip() == name)
            for src in files_section.findall("source")
        )
        if not exists:
            xbmc.log(f"[SourceHome] Adding {name} under <files>", xbmc.LOGINFO)
            source_elem = ET.Element("source")
            n = ET.SubElement(source_elem, "name"); n.text = name
            p = ET.SubElement(source_elem, "path", {"pathversion": "1"}); p.text = path_text
            allow = ET.SubElement(source_elem, "allowsharing"); allow.text = "true"
            default_elem = files_section.find("default")
            if default_elem is not None:
                files_section.insert(list(files_section).index(default_elem) + 1, source_elem)
            else:
                files_section.insert(0, source_elem)
            changed = True

    # Always ensure these two
    ensure_source(".Kodi Root Directory", "special://home/")
    ensure_source(".Imported_Files", "special://home/Imported_Files")
    ensure_source(".Active Skin Folder", "special://skin/")

    # Android-only
    if xbmc.getCondVisibility("system.platform.android"):
        ensure_source(".Device File Storage", "/storage/emulated/0/")

    # If anything changed or file was created, write back
    if created or changed:
        indent(root)
        tree.write(sources_path, encoding="UTF-8", xml_declaration=True)

    # Always make sure the Imported_Files directory exists
    imported_path = xbmcvfs.translatePath("special://home/Imported_Files")
    if not xbmcvfs.exists(imported_path):
        xbmcvfs.mkdirs(imported_path)

    return (created or changed)
    
