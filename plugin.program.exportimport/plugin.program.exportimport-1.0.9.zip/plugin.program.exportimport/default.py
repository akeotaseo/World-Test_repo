# -*- coding: utf-8 -*-
# default.py â€” File Import/Export + Download/Extract ZIP or AFTV Code + Maintenance Tools
# -----------------------------------------------------------------------------
# Main entry point for the Export/Import utility add-on.
#
# Features implemented in this file (before menus):
#   â€¢ File & Directory Export/Import (Kodi root â†” Device filesystem)
#   â€¢ ZIP Tools (Create, Extract, Download)
#   â€¢ Add-on Tools (Enable/Disable, Enable All, Disable All)
#   â€¢ Maintenance Tools (Cache/Packages/Thumbnails clearing)
#
# Menus for navigation are defined after "# ---------- Menus ----------"
# -----------------------------------------------------------------------------

import os
import re
import urllib.request
import urllib.error
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import zipfile
import json
import shutil
import requests
import sqlite3
from modules import aftv_downloader
from modules import aftv_apk_downloader
from modules import source_home
from modules import backup_manager
from modules import build_backup
from modules import userdata_backup
from modules import addons_backup
from modules import installer
from modules import apk_installer
from modules import saf_picker
from modules import remote_browser
from modules import remote_favorites
from modules import fav_sources_manager

# Global Add-on reference
ADDON = xbmcaddon.Addon()
CHUNK_SIZE = 1024 * 128  # 128 KB buffer size for streaming copies
HOME = xbmcvfs.translatePath("special://home/")

# =============================================================================
# HELPERS
# =============================================================================

def _copy_vfs(src_path, dst_path):
    """
    Copy a file between two Kodi VFS paths safely.
    Tries xbmcvfs.copy() first; if it fails, falls back to a
    manual read/write loop using xbmcvfs.File.
    """
    try:
        if xbmcvfs.copy(src_path, dst_path):
            return True
    except Exception:
        pass

    try:
        src_f = xbmcvfs.File(src_path, 'rb')
        dst_f = xbmcvfs.File(dst_path, 'wb')
        while True:
            chunk = src_f.read(CHUNK_SIZE)
            if not chunk:
                break
            dst_f.write(chunk)
        src_f.close()
        dst_f.close()
        return True
    except Exception:
        return False

def _copy_directory(src_folder, dst_folder):
    """
    Recursively copy an entire directory tree.
    Works across Kodi's VFS system for portability.
    """
    if not xbmcvfs.exists(dst_folder):
        xbmcvfs.mkdirs(dst_folder)

    dirs, files = xbmcvfs.listdir(src_folder)

    # Copy files
    for f in files:
        _copy_vfs(_join_path(src_folder, f), _join_path(dst_folder, f))

    # Copy subdirectories
    for d in dirs:
        _copy_directory(_join_path(src_folder, d), _join_path(dst_folder, d))

def _join_path(folder, name):
    """Safely join two paths in Kodi's VFS space."""
    return folder.rstrip('/') + '/' + name

# =============================================================================
# FILE/FOLDER BROWSERS
# =============================================================================

def browse_file_kodi_root(title):
    """Pick a file from Kodi's home folder."""
    return xbmcgui.Dialog().browse(1, title, 'files', '', False, False, 'special://home/')

def browse_folder_kodi_root(title):
    """Pick a folder from Kodi's home folder."""
    return xbmcgui.Dialog().browse(0, title, 'files', '', False, True, 'special://home/')


def browse_file_device_fs(title):
    """Pick a file from the device filesystem."""
    return xbmcgui.Dialog().browse(1, title, 'files', '', False, False, '')


def browse_folder_device_fs(title):
    """Pick a folder from the device filesystem."""
    return xbmcgui.Dialog().browse(0, title, 'files', '', False, True, '')

# =============================================================================
# DOWNLOAD FOLDER LOGIC
# =============================================================================

def get_download_folder():
    """
    Return the folder used for saving downloads.
    - If the setting 'use_imported_files' is enabled, use special://home/Imported_Files
    - Otherwise, ask the user to pick a folder from the device filesystem.
    """
    try:
        use_imported = ADDON.getSettingBool("use_imported_files")
    except Exception:
        use_imported = (ADDON.getSetting("use_imported_files").lower() == "true")

    if use_imported:
        folder = "special://home/Imported_Files"
        if not xbmcvfs.exists(folder):
            xbmcvfs.mkdirs(folder)
        return folder
    else:
        return browse_folder_device_fs("Select folder to save ZIP (device filesystem)")

# =============================================================================
# ACTIONS: FILE & DIRECTORY EXPORT/IMPORT
# =============================================================================

def export_file():
    """Export a single file from Kodi root â†’ device filesystem."""
    src = browse_file_kodi_root("Select file to export (Kodi root)")
    if not src:
        return
    dst_folder = browse_folder_device_fs("Select destination folder (device filesystem)")
    if not dst_folder:
        return
    dst = _join_path(dst_folder, os.path.basename(src))
    _copy_vfs(src, dst)

def import_file():
    """Import a single file from device filesystem â†’ Kodi root."""
    src = browse_file_device_fs("Select file to import (device filesystem)")
    if not src:
        return
    dst_folder = browse_folder_kodi_root("Select destination folder (Kodi root)")
    if not dst_folder:
        return
    dst = _join_path(dst_folder, os.path.basename(src))
    _copy_vfs(src, dst)

def export_directory():
    """Export a full directory from Kodi root â†’ device filesystem."""
    src_folder = browse_folder_kodi_root("Select directory to export (Kodi root)")
    if not src_folder:
        return
    dst_folder = browse_folder_device_fs("Select destination (device filesystem)")
    if not dst_folder:
        return
    dst = _join_path(dst_folder, os.path.basename(src_folder.rstrip('/')))
    _copy_directory(src_folder, dst)


def import_directory():
    """Import a full directory from device filesystem â†’ Kodi root."""
    src_folder = browse_folder_device_fs("Select directory to import (device filesystem)")
    if not src_folder:
        return
    dst_folder = browse_folder_kodi_root("Select destination (Kodi root)")
    if not dst_folder:
        return
    dst = _join_path(dst_folder, os.path.basename(src_folder.rstrip('/')))
    _copy_directory(src_folder, dst)

# =============================================================================
# ZIP TOOLS
# =============================================================================

def extract_zip():
    """Extract a ZIP file from device filesystem â†’ Kodi root."""
    src_zip = browse_file_device_fs("Select ZIP file to extract (device filesystem)")
    if not src_zip:
        return
    dst_folder = browse_folder_kodi_root("Select destination folder (Kodi root)")
    if not dst_folder:
        return

    dp = xbmcgui.DialogProgress()
    dp.create("Extracting", os.path.basename(src_zip))

    try:
        with zipfile.ZipFile(xbmcvfs.translatePath(src_zip), 'r') as zf:
            file_list = zf.namelist()
            total = len(file_list)
            for i, member in enumerate(file_list, 1):
                dp.update(int((i / total) * 100), f"Extracting: {member}")
                zf.extract(member, xbmcvfs.translatePath(dst_folder))
        dp.close()
        xbmcgui.Dialog().ok("Extract Complete", f"Files extracted to:\n{dst_folder}")
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok("Extract Failed", str(e))

def zip_directory():
    """Create a ZIP archive from a directory in Kodi root â†’ device filesystem."""
    src_folder = browse_folder_kodi_root("Select directory to zip (Kodi root)")
    if not src_folder:
        return
    dst_folder = browse_folder_device_fs("Select destination folder (device filesystem)")
    if not dst_folder:
        return
    zip_name = os.path.basename(src_folder.rstrip('/')) + ".zip"
    dst_zip = _join_path(dst_folder, zip_name)

    dp = xbmcgui.DialogProgress()
    dp.create("Creating ZIP", zip_name)

    try:
        with zipfile.ZipFile(xbmcvfs.translatePath(dst_zip), 'w', zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(xbmcvfs.translatePath(src_folder)):
                for f in files:
                    abs_path = os.path.join(root, f)
                    rel_path = os.path.relpath(abs_path, xbmcvfs.translatePath(src_folder))
                    dp.update(0, f"Adding: {rel_path}")
                    zf.write(abs_path, rel_path)
        dp.close()
        xbmcgui.Dialog().ok("ZIP Complete", f"Created:\n{dst_zip}")
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok("ZIP Failed", str(e))

def download_zip_from_url():
    """Download a ZIP from a URL and save to the chosen download folder."""
    url = xbmcgui.Dialog().input("Enter ZIP URL (http/https/ftp)")
    if not url:
        return
    save_folder = get_download_folder()
    if not save_folder:
        return

    from urllib.parse import urlsplit, unquote
    fname = unquote(os.path.basename(urlsplit(url).path)) or "download.zip"
    dest_vfs_path = _join_path(save_folder, fname)

    dp = xbmcgui.DialogProgress()
    dp.create("Downloading", fname)
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=45) as resp:
            out_f = xbmcvfs.File(dest_vfs_path, 'wb')
            while True:
                chunk = resp.read(CHUNK_SIZE)
                if not chunk:
                    break
                out_f.write(chunk)
            out_f.close()
        dp.close()
        xbmcgui.Dialog().ok("Download complete", f"Saved to:\n{dest_vfs_path}")
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok("Download Failed", str(e))

# =============================================================================
# ADD-ON TOOLS
# =============================================================================

def toggle_addons():
    """Prompt user to toggle a single add-on enabled/disabled."""
    result = xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0",
        "method": "Addons.GetAddons",
        "params": {"properties": ["name", "enabled"]},
        "id": 1
    }))
    data = json.loads(result)
    if "result" not in data or "addons" not in data["result"]:
        xbmcgui.Dialog().ok("Error", "Could not fetch add-ons list.")
        return

    addons = data["result"]["addons"]
    items = [f"[{'âœ“' if a['enabled'] else ' '}] {a['name']}" for a in addons]
    addon_ids = [a["addonid"] for a in addons]

    selected = xbmcgui.Dialog().select("Toggle Add-ons", items)
    if selected == -1:
        return

    selected_id = addon_ids[selected]
    new_state = not addons[selected]["enabled"]

    xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0",
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": selected_id, "enabled": new_state},
        "id": 1
    }))
    xbmcgui.Dialog().ok("Done", f"{'Enabled' if new_state else 'Disabled'}: {addons[selected]['name']}")

def enable_all_addons():
    """Force enable all installed add-ons."""
    result = xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0",
        "method": "Addons.GetAddons",
        "params": {"properties": ["enabled"]},
        "id": 1
    }))
    data = json.loads(result)
    if "result" not in data or "addons" not in data["result"]:
        xbmcgui.Dialog().ok("Error", "Could not fetch add-ons.")
        return

    for addon in data["result"]["addons"]:
        if not addon["enabled"]:
            xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {"addonid": addon["addonid"], "enabled": True},
                "id": 1
            }))
    xbmcgui.Dialog().ok("Done", "All add-ons enabled.")


def disable_all_addons():
    """Force disable all installed add-ons (except this export/import add-on)."""
    result = xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0",
        "method": "Addons.GetAddons",
        "params": {"properties": ["enabled"]},
        "id": 1
    }))
    data = json.loads(result)
    if "result" not in data or "addons" not in data["result"]:
        xbmcgui.Dialog().ok("Error", "Could not fetch add-ons.")
        return

    for addon in data["result"]["addons"]:
        if addon["addonid"] == "plugin.program.exportimport":
            continue
        if addon["enabled"]:
            xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {"addonid": addon["addonid"], "enabled": False},
                "id": 1
            }))
    xbmcgui.Dialog().ok("Done", "All add-ons disabled (export/import left active).")

# =============================================================================
# MAINTENANCE HELPERS
# =============================================================================

def _notify(title, msg):
    xbmcgui.Dialog().notification(title, msg, xbmcgui.NOTIFICATION_INFO, 3000)

def _delete_files_in(path, exts=None):
    """Delete files under path (optionally filtered by extensions). Returns count deleted."""
    deleted = 0
    if not os.path.exists(path):
        return 0
    for root, dirs, files in os.walk(path):
        for f in files:
            if exts and not any(f.lower().endswith(e) for e in exts):
                continue
            try:
                os.remove(os.path.join(root, f))
                deleted += 1
            except Exception:
                pass
    return deleted
    
# =============================================================================
# MAINTENANCE TOOLS
# =============================================================================

def clear_cache():
    path = os.path.join(HOME, "cache")
    count = _delete_files_in(path)
    _notify("Maintenance", f"Cleared {count} cache files.")

def clear_packages():
    path = os.path.join(HOME, "addons", "packages")
    count = _delete_files_in(path, exts=[".zip"])
    _notify("Maintenance", f"Cleared {count} packages.")

def clear_thumbnails():
    thumbs = os.path.join(HOME, "userdata", "Thumbnails")
    db = os.path.join(HOME, "userdata", "Database", "Textures13.db")

    count = _delete_files_in(thumbs)
    # reset Kodi's texture cache database too
    if os.path.exists(db):
        try:
            conn = sqlite3.connect(db)
            cur = conn.cursor()
            cur.execute("DELETE FROM texture")  # wipe cached entries
            conn.commit()
            conn.close()
        except Exception as e:
            xbmc.log(f"[Maintenance] Could not clear Textures13.db: {e}", xbmc.LOGERROR)

    _notify("Maintenance", f"Cleared {count} thumbnails and reset DB.")
       
# =============================================================================
# ---------- Menus ----------
# =============================================================================

def download_menu():
    options = [
       "Download ZIP from URL",
       "Download ZIP from AFTV Downloader Code",
       "Browse from Remote Server",
       "Browse Favorite URLs",
       "Install Add-on",
       "Install Build  (Custom Setup)",
       "Back"
    ]
    while True:
        sel = xbmcgui.Dialog().select("Download", options)
        if sel == -1 or options[sel] == "Back":
            break
        elif sel == 0:
            download_zip_from_url()
        elif sel == 1:
            aftv_downloader.install_zip_from_aftv_code()
        elif sel == 2:
            remote_browser.remote_browser_menu()
        elif sel == 3:
            remote_favorites.manage_favorites()
        elif sel == 4:
            from modules import installer
            installer.install_addon_menu()   # 🔹 full add-on menu   
        elif sel == 5:
            from modules import installer
            installer.install_build_menu()   # 🔹 full build menu

def backup_menu():
    options = [
        "Backup / Restore Build (Custom Setup)",
        "Backup / Restore Userdata Folder",
        "Backup / Restore Addons Folder",
        "Backup / Restore Favorites",
        "Backup / Restore Sources",
        "Back"
    ]
    while True:
        sel = xbmcgui.Dialog().select("Backup / Restore Menu", options)
        if sel == -1 or options[sel] == "Back":
            break
        elif sel == 0:
            backup_build_menu()
        elif sel == 1:
            backup_userdata_menu()
        elif sel == 2:
            backup_addons_menu()
        elif sel == 3:
            backup_fav_menu()
        elif sel == 4:
            backup_sources_menu()
            
def backup_build_menu():
    options = [
        "Backup Build (Custom Setup)",
        "Restore Build (Custom Setup)",
        "Back"
    ]
    while True:
        sel = xbmcgui.Dialog().select("Backup / Restore Build (SetUp)", options)
        if sel == -1 or options[sel] == "Back":
            break
        elif sel == 0:
            build_backup.create_root_backup()
        elif sel == 1:
            # 🔹 FIX: now show the full installer build menu
            from modules import installer
            installer.install_build_menu()      
        
def backup_userdata_menu():
    options = [
        "Backup Userdata",
        "Restore Userdata",
        "Back"
    ]
    while True:
        sel = xbmcgui.Dialog().select("Backup / Restore Userdata", options)
        if sel == -1 or options[sel] == "Back":
            break
        elif sel == 0:
            userdata_backup.backup_userdata()
        elif sel == 1:
            userdata_backup.restore_userdata()      

def backup_addons_menu():
    options = [
        "Backup Addons",
        "Restore Addons",
        "Back"
    ]
    while True:
        sel = xbmcgui.Dialog().select("Backup / Restore Addons", options)
        if sel == -1 or options[sel] == "Back":
            break
        elif sel == 0:
            addons_backup.backup_addons()
        elif sel == 1:
            addons_backup.restore_addons()        
               
def backup_fav_menu():
    options = [
        "Export Favorites",
        "Import Favorites",
        "Back"
    ]
    while True:
        sel = xbmcgui.Dialog().select("Backup Favorites / Sources", options)
        if sel == -1 or options[sel] == "Back":
            break
        elif sel == 0:
            fav_sources_manager.export_favorites()
        elif sel == 1:
            fav_sources_manager.import_favorites()
        elif sel == 2:
            fav_sources_manager.export_sources()
        elif sel == 3:
            fav_sources_manager.import_sources()

def backup_sources_menu():
    options = [
        "Export Sources",
        "Import Sources",
        "Back"
    ]
    while True:
        sel = xbmcgui.Dialog().select("Backup Favorites / Sources", options)
        if sel == -1 or options[sel] == "Back":
            break
        elif sel == 0:
            fav_sources_manager.export_favorites()
        elif sel == 1:
            fav_sources_manager.import_favorites()
        elif sel == 2:
            fav_sources_manager.export_sources()
        elif sel == 3:
            fav_sources_manager.import_sources()


def directory_menu():
    options = [
        "Export Directory (Kodi root → device fs)",
        "Import Directory (device fs → Kodi root)",
        "Export ZIP/File (Kodi root → device fs)",
        "Import ZIP/File (device fs → Kodi root)",
        "Back"
    ]
    while True:
        sel = xbmcgui.Dialog().select("Export/Import Menu", options)
        if sel == -1 or options[sel] == "Back":
            break
        elif sel == 0:
            export_directory()
        elif sel == 1:
            import_directory()
        elif sel == 2:
            export_file()
        elif sel == 3:
            import_file()

def zip_menu():
    options = [
         "Extract ZIP (device fs → Kodi root)",
         "Zip Directory (Kodi root → device fs)",
         "Back"
    ]
    while True:
        sel = xbmcgui.Dialog().select("ZIP Create / Extract", options)
        if sel == -1 or options[sel] == "Back":
            break
        elif sel == 0:
            extract_zip()
        elif sel == 1:
            zip_directory()

def installer_menu():
    options = [
         "Install Add-on",
         "Install Build (Custom Setup)",
         "Back"
    ]
    while True:
        sel = xbmcgui.Dialog().select("Select Install", options)
        if sel == -1 or options[sel] == "Back":
            break
        elif sel == 0:
            from modules import installer
            installer.install_addon_menu()   # 🔹 full add-on menu   
        elif sel == 1:
            from modules import installer
            installer.install_build_menu()   # 🔹 full build menu
 
def addons_menu():
    options = ["Enable / Disable Add-ons","Enable All Add-ons","Disable All Add-ons","Back"]
    while True:
        sel = xbmcgui.Dialog().select("Add-on Controls", options)
        if sel == -1 or options[sel] == "Back":
            break
        elif sel == 0:
            toggle_addons()
        elif sel == 1:
            enable_all_addons()
        elif sel == 2:
            disable_all_addons()

def binary_repair_menu():
    options = [
         "Force Install IPTV Simple Client & Binaries",
         "Back"
    ]
    while True:
        sel = xbmcgui.Dialog().select("Select Binary Repair", options)
        if sel == -1 or options[sel] == "Back":
            break
        elif sel == 0:  # NEW
            from modules import binary_repair
            binary_repair.force_clean_and_repair()   

def maintenance_menu():
    options = ["Enable / Disable Add-ons","Enable All Add-ons","Disable All Add-ons","Clear Cache","Clear Packages","Clear Thumbnails","Force Install IPTV Client(s) & Binaries","Back"]
    while True:
        sel = xbmcgui.Dialog().select("Maintenance Tools", options)
        if sel == -1 or options[sel] == "Back":
            break
        elif sel == 0:
            toggle_addons()
        elif sel == 1:
            enable_all_addons()
        elif sel == 2:
            disable_all_addons()           
        elif sel == 3:
            clear_cache()
        elif sel == 4:
            clear_packages()
        elif sel == 5:
            clear_thumbnails()
        elif sel == 6:
            binary_repair_menu()
   
def apk_menu():
    options = ["Download APK from AFTV Downloader Code", "Install APK From File System", "Back"]
    while True:
        sel = xbmcgui.Dialog().select("APK Menu", options)
        if sel == -1 or options[sel] == "Back":
            break
        elif sel == 0:
            aftv_downloader.install_zip_from_aftv_code()
        elif sel == 1:
            apk_installer.install_apk()            
            
def main():
    main_options = [
        "Export or Import Zip/File/Directory",           
        "Zip Downloader / Installer",                   
        "Zip Create or Extract",
        "APK Downloader / Installer",       
        "Backup or Restore",                   
        "Maintenance Tools",     
        "Backup Folder Settings",
        "Exit"                                 
    ]
    while True:
        sel = xbmcgui.Dialog().select("Main Menu", main_options)
        if sel == -1 or sel == 7:  # Exit
            break
        elif sel == 0:  
            directory_menu()
        elif sel == 1:  
            download_menu()    
        elif sel == 2:  
            zip_menu()
        elif sel == 3:
            apk_menu()               
        elif sel == 4:  
            backup_menu()                    
        elif sel == 5:  
            maintenance_menu()
        elif sel == 6:
            backup_manager.backup_settings_menu() 
            

# =============================================================================
# ---------- Notification Helper ----------
# =============================================================================

def notify_sources_added():
    xbmcgui.Dialog().ok(
        "Sources Added/Updated",
        "Sources have been added or updated.\n"
        "Restart Kodi for them to appear in File Manager and add-on pickers."
    )

# =============================================================================
# ---------- Entry Point ----------
# =============================================================================

if __name__ == '__main__':
    import xbmcaddon
    from modules import source_home

    addon = xbmcaddon.Addon()

    # Kodi 19+ has getSettingBool; older uses getSetting
    try:
        add_source_enabled = addon.getSettingBool("enable_kodi_root_source")
    except AttributeError:
        add_source_enabled = (addon.getSetting("enable_kodi_root_source") == "true")

    if add_source_enabled:
        changed = source_home.ensure_kodi_root_source()
        if changed:
            notify_sources_added()

    main()