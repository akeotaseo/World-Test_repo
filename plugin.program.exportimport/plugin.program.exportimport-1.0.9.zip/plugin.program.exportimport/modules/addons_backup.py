# modules/addons_backup.py
# Backup and restore Kodi's addons folder

import os
import zipfile
import xbmc
import xbmcgui
import xbmcvfs

from modules import path_helper

def backup_addons():
    dialog = xbmcgui.Dialog()
    kodi_root = path_helper.kodi_root()
    addons = os.path.join(kodi_root, "addons")
    default_name = path_helper.default_filename("AddonsBackup", ".zip")

    # Step 1: Pick destination safely
    dest_folder = path_helper.pick_safe_folder("Choose backup destination folder")
    if not dest_folder:
        return

    translated_dest = xbmcvfs.translatePath(dest_folder) if not dest_folder.startswith("saf://") else dest_folder

    # Block root except Imported_Files
    if translated_dest.startswith(kodi_root) and not translated_dest.endswith("Imported_Files"):
        dialog.ok("Kodi’s Little Helper",
                  "Backup cannot be saved in Kodi’s root directory!\nUse Imported_Files instead.")
        return

    # Step 2: Ask for filename
    filename = dialog.input("Backup file name (leave blank for default)",
                            type=xbmcgui.INPUT_ALPHANUM, defaultt=default_name)
    if filename:
        filename = filename.strip()
        if not filename.lower().endswith(".zip"):
            filename += ".zip"
    else:
        filename = default_name

    # Build full target path
    if dest_folder.startswith("saf://"):
        zip_path = path_helper.join_saf(dest_folder, filename)
    else:
        zip_path = os.path.join(translated_dest, filename)

    # Step 3: Collect files
    waitdlg = xbmcgui.DialogProgress()
    waitdlg.create("Kodi’s Little Helper", "Please wait… preparing addons file list")
    try:
        file_list = []
        for r, dirs, files in os.walk(addons):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            for f in files:
                abs_path = os.path.join(r, f)
                rel_path = os.path.relpath(abs_path, kodi_root)
                file_list.append((abs_path, rel_path))
    finally:
        waitdlg.close()

    # Step 4: Zip with progress
    dp = xbmcgui.DialogProgress()
    dp.create("Kodi’s Little Helper", "Creating addons backup…")
    try:
        zip_real = xbmcvfs.translatePath(zip_path) if not zip_path.startswith("saf://") else zip_path
        with zipfile.ZipFile(zip_real, "w", zipfile.ZIP_DEFLATED) as zipf:
            total = max(1, len(file_list))
            for idx, (abs_path, rel_path) in enumerate(file_list):
                try:
                    zipf.write(abs_path, rel_path)
                except Exception as e:
                    xbmc.log(f"[AddonsBackup] Failed to add {abs_path}: {e}", xbmc.LOGWARNING)

                percent = int((idx + 1) * 100 / total)
                if not dp.iscanceled():
                    dp.update(percent, f"Zipping: {rel_path}")
                else:
                    dp.close()
                    if not zip_path.startswith("saf://") and os.path.exists(zip_real):
                        os.remove(zip_real)
                    dialog.ok("Kodi’s Little Helper", "Backup canceled.")
                    return

        dp.close()
        dialog.ok("Kodi’s Little Helper", f"Addons backup created:\n[COLOR green]{zip_path}[/COLOR]")
        xbmc.log(f"[AddonsBackup] Backup created at {zip_path}", xbmc.LOGINFO)

    except Exception as e:
        try: dp.close()
        except: pass
        xbmc.log(f"[AddonsBackup] Failed to create backup: {e}", xbmc.LOGERROR)
        dialog.ok("Kodi’s Little Helper", f"[COLOR red]Backup failed[/COLOR]: {e}")


def restore_addons():
    dialog = xbmcgui.Dialog()
    kodi_root = path_helper.kodi_root()
    addons = os.path.join(kodi_root, "addons")

    # Pick source file
    src_zip = xbmcgui.Dialog().browse(
        1, "Select addons backup ZIP", "files", ".zip", False, False, ""
    )
    if not src_zip:
        return

    src_zip = xbmcvfs.translatePath(src_zip)

    # Extract
    dp = xbmcgui.DialogProgress()
    dp.create("Kodi’s Little Helper", "Restoring addons…")
    try:
        with zipfile.ZipFile(src_zip, 'r') as zf:
            file_list = zf.namelist()
            total = max(1, len(file_list))
            for idx, member in enumerate(file_list, 1):
                dp.update(int(idx * 100 / total), f"Extracting: {member}")
                zf.extract(member, kodi_root)
        dp.close()
        dialog.ok("Kodi’s Little Helper", f"Addons restored from:\n[COLOR green]{src_zip}[/COLOR]")
        xbmc.log(f"[AddonsBackup] Restored from {src_zip}", xbmc.LOGINFO)
    except Exception as e:
        try: dp.close()
        except: pass
        xbmc.log(f"[AddonsBackup] Restore failed: {e}", xbmc.LOGERROR)
        dialog.ok("Kodi’s Little Helper", f"[COLOR red]Restore failed[/COLOR]: {e}")
