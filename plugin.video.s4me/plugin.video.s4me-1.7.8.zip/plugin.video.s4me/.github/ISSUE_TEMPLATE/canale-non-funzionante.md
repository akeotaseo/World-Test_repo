---
name: Segnala Problemi ad un Canale
about: Invio segnalazione per un canale non funzionante
title: 'Inserisci il nome del canale'
labels: Problema Canale
assignees: ''

---

**Per poter scrivere o allegare file nella pagina devi:**
    - cliccare sui [ ... ] in alto a destra della scheda 
    - Edit. Da questo momento puoi scrivere e/o inviare file.


Inserisci il nome del canale


- Indica il tipo di problema riscontrato, sii il più esauriente possibile. Che azione ha portato all'errore (Es. non riesco ad aggiungere film nella videoteca, ne dal menu contestuale, ne dalla voce in fondo alla lista dei server)

- Ottieni il log seguendo le istruzioni: https://telegra.ph/LOG-11-20 e invialo qui.

