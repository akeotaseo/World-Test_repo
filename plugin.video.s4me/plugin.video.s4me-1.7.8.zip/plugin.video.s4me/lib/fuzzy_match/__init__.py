# __init__.py

# Version of the fuzzy-match package
__version__ = "0.0.1"