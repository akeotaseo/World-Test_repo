import sys
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmc
import resolveurl
import xbmcaddon

ADDON = xbmcaddon.Addon()
_handle = int(sys.argv[1])
_plugin_url = sys.argv[0]

def log(message, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON.getAddonInfo("id")}] {message}', level)

def build_url(query):
    return _plugin_url + '?' + urllib.parse.urlencode(query)

def main_menu():
    log('Displaying main menu.')
    xbmcplugin.setPluginCategory(_handle, 'Main Menu')
    li = xbmcgui.ListItem(label='[+] Input URL to Play')
    li.setProperty('IsPlayable', 'false')
    url = build_url({'action': 'get_and_play_url'})
    xbmcplugin.addDirectoryItem(handle=_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle)

def get_and_play_url():
    log('Action: get_and_play_url started.')
    keyboard = xbmc.Keyboard('', 'Enter video URL')
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        url_to_resolve = keyboard.getText()
        log(f'User entered URL: {url_to_resolve}')
        play_video(url_to_resolve)
    else:
        log('User cancelled the input dialog.')

def play_video(url):
    log(f'Attempting to resolve URL: {url}')
    try:
        resolved_url = resolveurl.resolve(url)
        log(f'ResolveURL result: {resolved_url}')

        if resolved_url:
            play_item = xbmcgui.ListItem(path=resolved_url)
            play_item.setInfo('video', {'title': 'Playing from URL'})

            player = xbmc.Player()
            player.play(resolved_url, play_item)
            log('Playback initiated successfully.')
        else:
            log('ResolveURL returned None or False. Cannot play.')
            xbmcgui.Dialog().notification('Error', 'Could not resolve the URL.', xbmcgui.NOTIFICATION_ERROR)
    except Exception as e:
        log(f'Exception: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Playback Error', str(e), xbmcgui.NOTIFICATION_ERROR)


def router():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    log(f'Router called with action: {action}')

    if action == 'get_and_play_url':
        get_and_play_url()
    else:
        main_menu()

if __name__ == '__main__':
    log('Plugin execution started.')
    router()
    log('Plugin execution finished.')