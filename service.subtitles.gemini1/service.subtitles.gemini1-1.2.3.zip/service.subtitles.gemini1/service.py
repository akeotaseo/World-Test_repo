import sys
import os
import json
import urllib.parse
import requests
import socket
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import time

ADDON = xbmcaddon.Addon()

def get_server_base_url():
    server_ip = ADDON.getSetting("remote_extractor_url").strip()
    if server_ip and not server_ip.startswith("http"):
        return f"http://{server_ip}"
    return server_ip

def get_all_api_keys():
    return [ADDON.getSetting(f"api_key_r3_{i}").strip() for i in range(1, 6)]

def get_selected_language():
    lang_index_str = ADDON.getSetting("subs_languages")
    lang_index = int(lang_index_str) if lang_index_str else 0
    languages = [
        "Română", "Engleză", "Spaniolă", "Franceză", "Germană", 
        "Italiană", "Maghiară", "Portugheză", "Rusă", "Turcă", 
        "Bulgară", "Greacă", "Poloneză", "Cehă", "Olandeză"
    ]
    return languages[lang_index] if 0 <= lang_index < len(languages) else "Română"

def get_absolute_addon_data_path():
    """Generează calea fizică directă către folderul userdata/addon_data din Windows."""
    try:
        appdata_roaming = os.environ.get('APPDATA')
        if appdata_roaming:
            target_dir = os.path.join(appdata_roaming, "Kodi", "userdata", "addon_data", "service.subtitles.gemini1")
            if not os.path.exists(target_dir):
                os.makedirs(target_dir, exist_ok=True)
            return target_dir
    except Exception:
        pass
    fallback_path = xbmcvfs.translatePath("special://profile/addon_data/service.subtitles.gemini1/")
    xbmcvfs.mkdir(fallback_path)
    return fallback_path

def scan_local_network_for_server():
    """Scanează rețeaua locală după serverul backend."""
    dialog = xbmcgui.Dialog()
    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create("Gemini Addon", "Se scanează rețeaua locală după serverul FFmpeg...")
    
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        ip_prefix = ".".join(local_ip.split(".")[:3]) + "."
    except Exception:
        ip_prefix = "192.168.1."
        
    found_ip = None
    total_hosts = 254
    
    for i in range(1, 255):
        if p_dialog.iscanceled():
            break
            
        current_ip = f"{ip_prefix}{i}"
        progress = int((i / total_hosts) * 100)
        p_dialog.update(progress, f"Se verifică: {current_ip}:8000")
        
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.08)
            result = sock.connect_ex((current_ip, 8000))
            if result == 0:
                payload = {"video_url": "", "movie_name": "", "duration_seconds": 0, "api_keys": []}
                headers = {'Content-Type': 'application/json'}
                res = requests.post(f"http://{current_ip}:8000/probe_tracks", data=json.dumps(payload), headers=headers, timeout=1)
                if res.status_code == 200:
                    found_ip = f"{current_ip}:8000"
                    sock.close()
                    break
            sock.close()
        except Exception:
            pass

    p_dialog.close()
    
    if found_ip:
        ADDON.setSetting("remote_extractor_url", found_ip)
        dialog.ok("Scanare Reușită", f"Serverul a fost găsit și salvat automat la adresa:\n[B]{found_ip}[/B]")
    else:
        dialog.ok("Scanare Eșuată", "Nu s-a găsit niciun server activ pe portul 8000.", "Asigură-te că server.py rulează pe PC.")
def list_translation_options(handle, video_url):
    """Interoghează pistele compatibile de pe server și le listează în interfața nativă."""
    server_url = get_server_base_url()
    if not server_url:
        xbmcgui.Dialog().ok("Configurare Incompletă", "Setați IP-ul serverului în setări.")
        return

    player = xbmc.Player()
    movie_name = xbmc.getInfoLabel("VideoPlayer.Title")
    if not movie_name:
        movie_name = video_url.split("/")[-1].split("?")[0]

    total_duration = player.getTotalTime()
    api_keys = get_all_api_keys()
    target_lang = get_selected_language()

    payload = {
        "video_url": video_url,
        "movie_name": movie_name,
        "duration_seconds": total_duration,
        "api_keys": api_keys
    }

    try:
        headers = {'Content-Type': 'application/json'}
        res = requests.post(f"{server_url}/probe_tracks", data=json.dumps(payload), headers=headers, timeout=12)
        if res.status_code != 200:
            xbmcplugin.endOfDirectory(handle, False)
            return
        tracks = res.json()
    except Exception as e:
        xbmc.log(f"[Gemini UI] Conexiune refuzată la probe: {str(e)}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, False)
        return

    for t in tracks.get("text", []):
        if t["compatible"]:
            params = {
                "action": "download",
                "video_url": video_url,
                "track_index": str(t["index"]),
                "is_audio": "false",
                "lang": target_lang
            }
            url = f"{sys.argv[0]}?{urllib.parse.urlencode(params)}"
            list_item = xbmcgui.ListItem(label=f"Gemini AI ({target_lang}) - Traduce text: {t['label']}")
            list_item.setProperties({"language_name": target_lang, "sync": "true"})
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=list_item, isFolder=False)

    for a in tracks.get("audio", []):
        params = {
            "action": "download",
            "video_url": video_url,
            "track_index": str(a["index"]),
            "is_audio": "true",
            "lang": target_lang
        }
        url = f"{sys.argv[0]}?{urllib.parse.urlencode(params)}"
        list_item = xbmcgui.ListItem(label=f"Gemini AI ({target_lang}) - Transcrie audio: {a['label']}")
        list_item.setProperties({"language_name": target_lang, "sync": "true"})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(handle, True)

def download_and_assemble_subtitle(handle, params):
    server_url = get_server_base_url()
    base_folder = get_absolute_addon_data_path()
    master_srt_path = os.path.join(base_folder, "gemini_live.srt")
    
    # Curățăm fișierul la început
    try:
        with open(master_srt_path, "w", encoding="utf-8", newline='\n') as f_init:
            f_init.write("")
    except Exception:
        pass

    v_url = params.get("video_url", [""])[0]
    t_idx = params.get("track_index", ["0"])[0]
    is_aud = params.get("is_audio", ["false"])[0]
    chosen_lang = params.get("lang", ["Română"])[0]

    query_params = {
        "video_url": v_url,
        "track_index": int(t_idx),
        "is_audio": is_aud.lower() == "true",
        "lang": chosen_lang
    }

    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create("Gemini AI Subtitles Provider", "Conectare la server...")

    try:
        session = requests.Session()
        response = session.get(f"{server_url}/stream_subtitles", params=query_params, stream=True, timeout=300)
        
        notificare_salvata_curenta = ""
        pachet_0_livrat = False
        
        # Variabilă pentru a măsura timpul de la ultimul refresh forțat în Android
        last_refresh_time = time.time()

        # Deschidem fișierul în modul 'a+' (append și read) - ajută la menținerea descriptorului pe Android
        with open(master_srt_path, "a+", encoding="utf-8", newline='\n') as f_write:
            
            for line_bytes in response.iter_lines():
                if p_dialog.iscanceled():
                    break

                line = line_bytes.decode('utf-8', errors='ignore').replace('\r', '').strip() if line_bytes else ""
                
                if line.startswith("KODI_NOTIFY|"):
                    notificare_salvata_curenta = line.replace("KODI_NOTIFY|", "").strip()
                    continue  

                if line.startswith("DATA_CHUNK_"):
                    new_chunk_id = line.replace("DATA_CHUNK_", "").strip()
                    
                    # Logica de predare inițială (Pachetul 0)
                    if not pachet_0_livrat and new_chunk_id != "0" and not query_params["is_audio"]:
                        pachet_0_livrat = True
                        p_dialog.close()
                        
                        list_item = xbmcgui.ListItem(label="gemini_live.srt")
                        xbmcplugin.addDirectoryItem(handle=handle, url=master_srt_path, listitem=list_item, isFolder=False)
                        xbmcplugin.endOfDirectory(handle, True)
                        
                        xbmc.sleep(500) # Timp de siguranță crescut pentru Android OS
                        xbmc.Player().setSubtitles(master_srt_path)
                        last_refresh_time = time.time()
                    continue
                
                # Când un bloc întreg s-a terminat de descărcat
                if line == "[BLOC_END]" or (line == "DATA_CHUNK_FINAL" and not query_params["is_audio"]):
                    f_write.write("\n")
                    f_write.flush()
                    os.fsync(f_write.fileno()) # 🔥 IMPORTANT PENTRU ANDROID: Forțează sistemul de fișiere să scrie pe stocarea fizică, nu în cache-ul virtual
                    
                    if not pachet_0_livrat:
                        pachet_0_livrat = True
                        p_dialog.close()
                        list_item = xbmcgui.ListItem(label="gemini_live.srt")
                        xbmcplugin.addDirectoryItem(handle=handle, url=master_srt_path, listitem=list_item, isFolder=False)
                        xbmcplugin.endOfDirectory(handle, True)
                        xbmc.sleep(500)
                        xbmc.Player().setSubtitles(master_srt_path)
                    else:
                        # Throttling pentru Android: re-injectăm subtitrarea DOAR la final de bloc, 
                        # prevenind micro-stutter-ul, dar asigurând că textul nou este citit
                        current_time = time.time()
                        if current_time - last_refresh_time >= 4.0: # Re-indexare la minim 4 secunde distanță
                            xbmc.Player().setSubtitles(master_srt_path)
                            last_refresh_time = current_time
                    
                    if notificare_salvata_curenta:
                        xbmcgui.Dialog().notification("Gemini AI", notificare_salvata_curenta, xbmcgui.NOTIFICATION_INFO, 1500, False)
                        notificare_salvata_curenta = ""
                
                else:
                    # Scrierea fiecărei linii standard
                    f_write.write(line + "\n")
                    f_write.flush()

        # 🚨 🔥 FAILSAPE PENTRU ULTIMELE MINUTE (Adăugat în afara buclei For) 🔥 🚨
        # Stream-ul s-a închis brusc după ultimul anunț. Salvăm forțat ultimele rânduri primite.
        try:
            with open(master_srt_path, "a", encoding="utf-8", newline='\n') as f_final:
                f_final.write("\n\n\n") # Cele 3 linii goale obligatorii pentru parserul Android SRT
                f_final.flush()
                try:
                    os.fsync(f_final.fileno()) # Împingem textul fizic pe cipul de stocare
                except:
                    pass
            
            # Îi dăm timp scurt stocării Android (600ms) și facem un Refresh Final de siguranță
            if pachet_0_livrat:
                xbmc.sleep(600)
                xbmc.Player().setSubtitles(master_srt_path) # Încarcă ultimele fraze din film în player
                xbmc.log("[Gemini UI] Refresh-ul final a securizat ultimele minute pe ecran.", xbmc.LOGINFO)
            
            # Afișăm pop-up-ul suprem de finalizare (🏁) trimis de server
            if notificare_salvata_curenta:
                xbmcgui.Dialog().notification("Gemini AI", notificare_salvata_curenta, xbmcgui.NOTIFICATION_INFO, 3500, False)
                notificare_salvata_curenta = ""
                
        except Exception as final_err:
            xbmc.log(f"[Gemini UI] Eroare la salvarea bucății de final: {str(final_err)}", xbmc.LOGERROR)

        p_dialog.close()
    except Exception as e:
        if 'p_dialog' in locals(): p_dialog.close()
        xbmc.log(f"[Gemini UI] Eroare Android Stream: {str(e)}", xbmc.LOGERROR)
# ------------------------------------------------------------------------------
# 🚀 PARSER INTEGRAL ȘI SIGUR DE ARGUMENTE NATIVE KODI (CORECTAT CRITICAL)
# ------------------------------------------------------------------------------

if __name__ == "__main__":
    args_str = " ".join(sys.argv)
    
    if "action=autoscan" in args_str:
        scan_local_network_for_server()
        sys.exit()

    if len(sys.argv) > 1:
        plugin_handle = -1
        # 🔥 CORECTURĂ: Verificăm dacă primul argument trimis de Kodi este număr (handle-ul de plugin)
        if len(sys.argv) > 1 and str(sys.argv[1]).isdigit():
            plugin_handle = int(sys.argv[1])

        # 🔥 CORECTURĂ: Extragem corect textul curat din query_string al listei de argumente
        query_string = sys.argv[2] if len(sys.argv) > 2 else ""
        if query_string.startswith("?"):
            query_string = query_string[1:]
            
        parsed_params = urllib.parse.parse_qs(query_string)
        # Extragem valoarea acțiunii din dicționarul de liste
        action = parsed_params.get("action", [""])[0]

        if action == "download":
            download_and_assemble_subtitle(plugin_handle, parsed_params)
        else:
            current_video = xbmc.Player().getPlayingFile()
            if current_video and current_video.startswith("http"):
                list_translation_options(plugin_handle, current_video)
            else:
                if plugin_handle != -1:
                    xbmcplugin.endOfDirectory(plugin_handle, False)
